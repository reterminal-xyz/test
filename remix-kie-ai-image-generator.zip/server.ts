import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const PORT = 3000;
const KIE_BASE_URL = 'https://api.kie.ai';

async function startServer() {
  const app = express();

  app.use(express.json({ limit: '10mb' }));

  // Helper to extract multiple candidate API keys (from body.apiKeys, header x-api-keys, Authorization Bearer, or environment)
  const getApiKeys = (req: express.Request): string[] => {
    const keys: string[] = [];

    const addKey = (k: any) => {
      if (typeof k === 'string') {
        const trimmed = k.trim();
        if (trimmed && trimmed !== 'undefined' && trimmed !== 'null' && !keys.includes(trimmed)) {
          keys.push(trimmed);
        }
      }
    };

    // 1. From body.apiKeys (array of strings or single string)
    if (Array.isArray(req.body?.apiKeys)) {
      req.body.apiKeys.forEach(addKey);
    } else if (req.body?.apiKey) {
      addKey(req.body.apiKey);
    }

    // 2. From header x-api-keys
    const headerKeys = req.headers['x-api-keys'];
    if (typeof headerKeys === 'string') {
      try {
        const parsed = JSON.parse(headerKeys);
        if (Array.isArray(parsed)) {
          parsed.forEach(addKey);
        }
      } catch {
        headerKeys.split(',').forEach(addKey);
      }
    }

    // 3. From Authorization: Bearer <key>
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      addKey(authHeader.substring(7));
    }

    // 4. From server environment variable
    const envKey = process.env.KIE_AI_API_KEY?.trim();
    if (envKey) {
      envKey.split(',').forEach(addKey);
    }

    return keys;
  };

  // Helper to get primary active API key
  const getApiKey = (req: express.Request): string | null => {
    const candidateKeys = getApiKeys(req);
    return candidateKeys.length > 0 ? candidateKeys[0] : null;
  };

  // Helper to query credit balance for a given API key
  async function fetchCredit(apiKey: string): Promise<{
    valid: boolean;
    credit: number | string;
    raw?: any;
    error?: string;
  }> {
    try {
      const response = await fetch(`${KIE_BASE_URL}/api/v1/chat/credit`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        return {
          valid: false,
          credit: 0,
          error: `HTTP ${response.status}: ${errorText || response.statusText}`,
        };
      }

      const data = await response.json();
      let creditVal: number | string = 0;

      if (data.data !== undefined) {
        if (typeof data.data === 'number') {
          creditVal = data.data;
        } else if (typeof data.data === 'object' && data.data !== null) {
          creditVal = data.data.credit ?? data.data.balance ?? data.data.remaining ?? 0;
        } else if (typeof data.data === 'string') {
          const num = parseFloat(data.data);
          creditVal = isNaN(num) ? data.data : num;
        }
      } else if (data.credit !== undefined) {
        creditVal = data.credit;
      }

      return {
        valid: true,
        credit: creditVal,
        raw: data,
      };
    } catch (err: any) {
      return {
        valid: false,
        credit: 0,
        error: err.message || 'Gagal menghubungi Kie.ai',
      };
    }
  }

  // Detect whether an error indicates credit exhausted or key failure that warrants failover
  function isCreditOrAuthError(statusCode: number, errorMsg: string, data?: any): boolean {
    if (statusCode === 401 || statusCode === 402 || statusCode === 403 || statusCode === 429) {
      return true;
    }
    const combined = `${errorMsg} ${JSON.stringify(data || '')}`.toLowerCase();
    return (
      combined.includes('credit') ||
      combined.includes('balance') ||
      combined.includes('insufficient') ||
      combined.includes('quota') ||
      combined.includes('arrears') ||
      combined.includes('not enough') ||
      combined.includes('no enough') ||
      combined.includes('out of') ||
      combined.includes('habis') ||
      combined.includes('unauthorized') ||
      combined.includes('token') ||
      combined.includes('payment') ||
      combined.includes('余额不足') ||
      combined.includes('点数不足')
    );
  }

  const uploadedReferences = new Map<string, { buffer: Buffer; contentType: string; fileName: string }>();

  // 1. Config endpoint
  app.get('/api/config', (req, res) => {
    const hasServerKey = Boolean(process.env.KIE_AI_API_KEY && process.env.KIE_AI_API_KEY.trim().length > 0);
    const hasGeminiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
    res.json({
      hasServerKey,
      hasGeminiKey,
      geminiModel: 'gemini-3.5-flash',
      defaultModel: 'gpt-image-2-5-flare-text-to-image',
      supportedModels: [
        {
          id: 'gpt-image-2-5-flare-text-to-image',
          name: 'GPT Image 2.5 Flare',
          badge: 'Recommended',
          description: 'Fastest OpenAI image generation & image-to-image editing model with sharp details, realistic lighting & 50% lower latency.',
        },
        {
          id: 'gpt-image-2-5-sunburst-text-to-image',
          name: 'GPT Image 2.5 Sunburst',
          badge: 'Ultra High Detail',
          description: 'Optimized for intricate artistic details, complex scenes, and maximum prompt adherence.',
        },
        {
          id: 'gpt-image-2-text-to-image',
          name: 'GPT Image 2.0',
          badge: 'Legacy',
          description: 'Standard OpenAI photorealistic image synthesis engine.',
        }
      ],
      aspectRatios: [
        { id: '1:1', label: 'Square (1:1)', width: 1024, height: 1024, icon: 'Square' },
        { id: '16:9', label: 'Landscape (16:9)', width: 1344, height: 768, icon: 'RectangleHorizontal' },
        { id: '9:16', label: 'Story / Portrait (9:16)', width: 768, height: 1344, icon: 'RectangleVertical' },
        { id: '4:3', label: 'Classic (4:3)', width: 1152, height: 864, icon: 'LayoutGrid' },
        { id: '3:4', label: 'Editorial (3:4)', width: 864, height: 1152, icon: 'Columns' },
        { id: '3:2', label: 'Photo (3:2)', width: 1216, height: 832, icon: 'Camera' },
        { id: '2:3', label: 'Poster (2:3)', width: 832, height: 1216, icon: 'Film' }
      ],
      qualities: [
        { id: 'low', label: 'Low', desc: 'Fastest preview' },
        { id: 'medium', label: 'Medium', desc: 'Balanced speed' },
        { id: 'high', label: 'High', desc: 'Optimal fidelity (default)' },
        { id: 'xhigh', label: 'Extra High', desc: 'Refined textures' },
        { id: 'max', label: 'Max (4K)', desc: 'Ultimate resolution' }
      ]
    });
  });

  // Helper to extract Gemini API key from request or environment
  const getGeminiApiKey = (req: express.Request): string | null => {
    if (typeof req.body?.geminiApiKey === 'string' && req.body.geminiApiKey.trim()) {
      return req.body.geminiApiKey.trim();
    }
    const headerKey = req.headers['x-gemini-api-key'];
    if (typeof headerKey === 'string' && headerKey.trim()) {
      return headerKey.trim();
    }
    const auth = req.headers.authorization;
    if (auth && auth.startsWith('Bearer ')) {
      const token = auth.substring(7).trim();
      if (token.startsWith('AIza')) {
        return token;
      }
    }
    const envKey = process.env.GEMINI_API_KEY?.trim();
    if (envKey) {
      return envKey;
    }
    return null;
  };

  // Endpoint: Test Gemini API Key validity
  app.post('/api/gemini/test-key', async (req, res) => {
    try {
      const key = req.body?.key?.trim() || getGeminiApiKey(req);
      if (!key) {
        res.status(400).json({ valid: false, error: 'Gemini API key tidak boleh kosong.' });
        return;
      }

      const ai = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const candidateModels = [
        'gemini-3.5-flash',
        'gemini-3.8-flash',
        'gemini-flash-latest',
      ];

      let lastError = 'Koneksi ke Gemini AI gagal.';
      for (const modelName of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: 'Say OK',
          });
          if (response.text) {
            res.json({
              valid: true,
              model: modelName,
              message: `Gemini API key valid dan aktif menggunakan model ${modelName}!`,
            });
            return;
          }
        } catch (err: any) {
          lastError = err.message || String(err);
        }
      }

      res.status(400).json({ valid: false, error: lastError });
    } catch (e: any) {
      res.status(500).json({ valid: false, error: e.message || 'Internal server error saat menguji Gemini key' });
    }
  });

  // Endpoint: AI Enhance Prompt via Gemini AI (Gemini 3.5 Flash)
  app.post('/api/enhance-prompt', async (req, res) => {
    try {
      const { prompt, style = 'auto', hasReferenceImage = false } = req.body;

      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        res.status(400).json({ error: 'Prompt tidak boleh kosong untuk diperjelas.' });
        return;
      }

      const apiKey = getGeminiApiKey(req);
      if (!apiKey) {
        res.status(401).json({
          error: 'Gemini API Key belum diisi. Masukkan Gemini API Key Anda melalui menu Kunci API atau tombol Gemini di atas input deskripsi.',
          missingKey: true,
        });
        return;
      }

      // Build style-specific guidance
      let styleGuidance = 'Create a balanced, high-fidelity visual description with rich sensory details.';
      if (style === 'photorealistic') {
        styleGuidance = 'Focus on hyper-realistic photographic aesthetics: 8k resolution, Hasselblad/Sony A7R IV lens characteristics, natural skin/surface microtextures, cinematic volumetric lighting, raytraced reflections, authentic depth of field, real-world color science.';
      } else if (style === 'creative') {
        styleGuidance = 'Focus on imaginative concept art, whimsical or dramatic surrealism, evocative color palettes, dynamic visual metaphor, moody atmospheric diffusion, and evocative storytelling composition.';
      } else if (style === 'anime') {
        styleGuidance = 'Focus on high-end modern Japanese animation aesthetics: Makoto Shinkai & Ufotable style background art, crisp linework, vibrant anime color grading, expressive lighting, cel shading, and beautiful atmospheric particles.';
      } else if (style === 'clarity') {
        styleGuidance = 'Focus on direct clarity: remove filler words, eliminate ambiguous jargon, convert vague concepts into tangible visual nouns and lighting keywords, clean and punchy.';
      }

      const systemPrompt = `You are a world-class prompt engineer specializing in modern text-to-image and image-to-image AI models (GPT-Image 2.5 Flare, GPT-Image 2.5 Sunburst, DALL-E 3, Midjourney v6).
Your goal is to transform the user's raw image description or idea into a vivid, highly detailed, visually coherent prompt.

RULES:
1. Elaborate on the core subject: precise visual features, materials, clothing textures, anatomy, poses, and expressions.
2. Enrich the background & environment: spatial depth, environmental elements (mist, neon reflections, dust motes, foliage), architectural or natural context.
3. Define lighting & atmosphere: key lights, rim highlights, volumetric shafts, color bounce, time of day.
4. Specify camera & composition: perspective (e.g. low-angle, macro, wide cinematic), lens type (e.g. 50mm f/1.2, 85mm portrait), focal plane, framing.
5. Style guidance: ${styleGuidance}
6. If the user mentions modifying a reference image (${hasReferenceImage ? 'YES, reference image is present' : 'NO, text-to-image'}): formulate the output as clear instructions for image-to-image transformation, emphasizing what to preserve and what to transform.
7. Language handling: If user writes in Indonesian or other languages, output the enhanced prompt in English for optimal image synthesis adherence, while accurately maintaining every specific cultural or artistic detail intended.
8. CRITICAL: Output ONLY the enhanced prompt itself. Do NOT output conversational greetings ("Here is your prompt:"), no markdown codeblocks, no bullet lists, no quotation marks. Just the clean enhanced prompt text ready to be fed into the image generator.`;

      const userMessage = `Original prompt idea:
"""
${prompt.trim()}
"""

Please enhance and enrich this prompt into an optimal, highly detailed image generation prompt following the style guidelines.`;

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      // User requested "gemini 3.5 flash"; fallback gracefully if alias not found
      const candidateModels = [
        'gemini-3.5-flash',
        'gemini-3.8-flash',
        'gemini-flash-latest',
      ];

      let enhancedResult = '';
      let usedModel = '';
      let lastError = 'Gagal memproses prompt dengan Gemini AI.';

      for (const modelName of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: userMessage,
            config: {
              systemInstruction: systemPrompt,
              temperature: 0.7,
            },
          });

          const rawText = response.text;
          if (rawText && typeof rawText === 'string' && rawText.trim()) {
            let clean = rawText.trim();
            // Strip surrounding quotes or code fences if present
            clean = clean.replace(/^```[\w]*\n?|```$/g, '').trim();
            clean = clean.replace(/^["'`]+|["'`]+$/g, '').trim();
            clean = clean.replace(/^(enhanced prompt|output|prompt):\s*/i, '').trim();

            enhancedResult = clean;
            usedModel = modelName;
            break;
          }
        } catch (mErr: any) {
          lastError = mErr.message || String(mErr);
          // Try next candidate model
        }
      }

      if (!enhancedResult) {
        res.status(500).json({ error: lastError });
        return;
      }

      res.json({
        success: true,
        enhancedPrompt: enhancedResult,
        originalPrompt: prompt.trim(),
        modelUsed: usedModel,
        style,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memperjelas prompt dengan Gemini AI.' });
    }
  });

  // Helper function to upload an image buffer directly to Kie.ai's official file-base64-upload API
  async function uploadToKieCloud(
    apiKey: string,
    buffer: Buffer,
    originalFileName: string,
    contentType: string
  ): Promise<string> {
    const isPng = contentType.toLowerCase().includes('png');
    const ext = isPng ? 'png' : 'jpg';
    const cleanBase = originalFileName
      .replace(/\.[^/.]+$/, '')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 30) || 'reference';
    const cleanName = `ref_${Date.now()}_${cleanBase}.${ext}`;
    const mimeType = isPng ? 'image/png' : 'image/jpeg';
    const pureBase64 = buffer.toString('base64');
    const dataUriBase64 = `data:${mimeType};base64,${pureBase64}`;

    // Candidate endpoints: official docs state https://api.kie.ai/api/file-base64-upload and https://kieai.redpandaai.co/api/file-base64-upload
    const candidateEndpoints = [
      'https://api.kie.ai/api/file-base64-upload',
      'https://kieai.redpandaai.co/api/file-base64-upload',
      `${KIE_BASE_URL}/api/file-base64-upload`,
      `${KIE_BASE_URL}/api/v1/file-base64-upload`,
    ];
    const uniqueEndpoints = Array.from(new Set(candidateEndpoints));

    // Try both data URI and pure base64 formats if necessary
    const payloads = [
      {
        base64Data: dataUriBase64,
        uploadPath: 'images/base64',
        fileName: cleanName,
      },
      {
        base64Data: pureBase64,
        uploadPath: 'images/base64',
        fileName: cleanName,
      },
    ];

    let lastError: any = null;

    for (const endpoint of uniqueEndpoints) {
      for (const payload of payloads) {
        try {
          const uploadRes = await fetch(endpoint, {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${apiKey.trim()}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
          });

          const uploadText = await uploadRes.text();
          let uploadData: any = {};
          try {
            uploadData = JSON.parse(uploadText);
          } catch {
            uploadData = { raw: uploadText };
          }

          // If 404 or generic Spring Boot "No message available", endpoint is invalid, continue to next
          if (
            uploadRes.status === 404 ||
            (uploadData?.message && uploadData.message.includes('No message available'))
          ) {
            lastError = new Error(`Endpoint ${endpoint} tidak ditemukan (404).`);
            break; // Skip to next endpoint
          }

          // If auth error, stop immediately with friendly message
          if (uploadRes.status === 401 || uploadRes.status === 403) {
            throw new Error('API Key Kie.ai tidak valid atau tidak memiliki izin akses.');
          }

          if (!uploadRes.ok || (uploadData.code && uploadData.code !== 200)) {
            const rawMsg = uploadData?.message || uploadData?.msg || uploadData?.error;
            let errorMsg = rawMsg && rawMsg !== 'No message available'
              ? rawMsg
              : `Gagal mengunggah berkas ke Kie.ai (${uploadRes.status})`;
            lastError = new Error(errorMsg);
            continue; // Try next payload format or endpoint
          }

          const fileUrl =
            uploadData?.data?.downloadUrl ||
            uploadData?.data?.fileUrl ||
            uploadData?.downloadUrl ||
            uploadData?.fileUrl ||
            (uploadData?.data && typeof uploadData.data === 'string' && uploadData.data.startsWith('http')
              ? uploadData.data
              : null);

          if (fileUrl) {
            return fileUrl;
          }

          lastError = new Error('Kie.ai tidak mengembalikan downloadUrl yang valid.');
        } catch (fetchErr: any) {
          if (fetchErr.message?.includes('API Key Kie.ai tidak valid')) {
            throw fetchErr;
          }
          lastError = fetchErr;
        }
      }
    }

    const finalErrMsg =
      lastError?.message && lastError.message !== 'No message available'
        ? lastError.message
        : 'Gagal mengunggah berkas gambar referensi ke Kie.ai Cloud. Pastikan API key benar dan koneksi internet stabil.';
    throw new Error(finalErrMsg);
  }

  // Helper to extract YouTube video ID from various link formats or raw ID
  function extractYouTubeVideoId(input: string): string | null {
    if (!input || typeof input !== 'string') return null;
    const trimmed = input.trim();
    // 11-char direct video ID
    if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
      return trimmed;
    }
    // YouTube links: watch?v=, youtu.be/, shorts/, embed/, live/, img.youtube.com/vi/
    const regex = /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/|live\/)|img\.youtube\.com\/vi\/|i\.ytimg\.com\/vi\/)([a-zA-Z0-9_-]{11})/i;
    const match = trimmed.match(regex);
    return match ? match[1] : null;
  }

  // Helper to fetch the best available YouTube thumbnail (maxresdefault -> sddefault -> hqdefault)
  async function fetchYouTubeThumbnail(videoId: string): Promise<{
    buffer: Buffer;
    contentType: string;
    fileName: string;
    quality: string;
    sourceUrl: string;
  }> {
    const candidates = [
      { name: 'HD 1080p/720p (maxresdefault)', quality: 'maxresdefault', url: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` },
      { name: 'SD 480p (sddefault)', quality: 'sddefault', url: `https://img.youtube.com/vi/${videoId}/sddefault.jpg` },
      { name: 'HQ 360p (hqdefault)', quality: 'hqdefault', url: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` },
    ];

    for (const c of candidates) {
      try {
        const res = await fetch(c.url);
        if (res.ok) {
          const arrayBuffer = await res.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          // When maxresdefault doesn't exist, YouTube sometimes returns a 120x90 transparent gif/jpg (~1097 bytes)
          if (buffer.length > 2500 || c.quality === 'hqdefault') {
            return {
              buffer,
              contentType: 'image/jpeg',
              fileName: `yt_${videoId}_${c.quality}.jpg`,
              quality: c.quality,
              sourceUrl: c.url,
            };
          }
        }
      } catch {
        // Try next resolution
      }
    }

    // Ultimate fallback
    const fallbackRes = await fetch(`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`);
    if (!fallbackRes.ok) {
      throw new Error(`Gagal mengambil thumbnail YouTube untuk ID video: ${videoId}`);
    }
    const arrayBuffer = await fallbackRes.arrayBuffer();
    return {
      buffer: Buffer.from(arrayBuffer),
      contentType: 'image/jpeg',
      fileName: `yt_${videoId}_hqdefault.jpg`,
      quality: 'hqdefault',
      sourceUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
    };
  }

  // Serve locally uploaded reference images
  app.get('/api/uploaded-reference/:id', (req, res) => {
    const item = uploadedReferences.get(req.params.id);
    if (!item) {
      res.status(404).send('Reference image not found');
      return;
    }
    res.setHeader('Content-Type', item.contentType);
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(item.buffer);
  });

  // Upload Reference Image Endpoint (supports file base64, external image URL, and YouTube video thumbnail)
  app.post('/api/upload-reference', async (req, res) => {
    try {
      const apiKey = getApiKey(req);
      const { base64Data, imageUrl, youtubeUrl, fileName = 'reference.jpg' } = req.body;

      // Case A: YouTube URL or detected YouTube link in imageUrl
      const targetYt = youtubeUrl || (imageUrl && extractYouTubeVideoId(imageUrl) ? imageUrl : null);
      if (targetYt && typeof targetYt === 'string') {
        const videoId = extractYouTubeVideoId(targetYt);
        if (!videoId) {
          res.status(400).json({
            error: 'Format tautan YouTube tidak valid. Harap masukkan tautan video, Shorts, atau Video ID yang benar.',
          });
          return;
        }

        try {
          const ytThumb = await fetchYouTubeThumbnail(videoId);
          const id = `yt_${videoId}_${Date.now()}`;
          uploadedReferences.set(id, {
            buffer: ytThumb.buffer,
            contentType: ytThumb.contentType,
            fileName: ytThumb.fileName,
          });

          // If apiKey available, upload to Kie.ai Cloud CDN
          if (apiKey) {
            try {
              const cloudUrl = await uploadToKieCloud(
                apiKey,
                ytThumb.buffer,
                ytThumb.fileName,
                ytThumb.contentType
              );
              res.json({
                success: true,
                url: cloudUrl,
                previewUrl: ytThumb.sourceUrl,
                source: 'kie-cloud',
                videoId,
                quality: ytThumb.quality,
                fileName: `YouTube (${videoId})`,
              });
              return;
            } catch (upErr: any) {
              console.warn('YouTube thumbnail upload to Kie cloud failed, using local/source fallback:', upErr.message);
            }
          }

          // Fallback: local or direct ytimg preview URL
          const host = req.get('host') || 'localhost:3000';
          const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
          const localUrl = `${protocol}://${host}/api/uploaded-reference/${id}.jpg`;

          res.json({
            success: true,
            url: localUrl,
            previewUrl: ytThumb.sourceUrl,
            source: 'local',
            videoId,
            quality: ytThumb.quality,
            fileName: `YouTube (${videoId})`,
          });
          return;
        } catch (ytErr: any) {
          res.status(400).json({ error: ytErr.message || 'Gagal mengunduh thumbnail dari YouTube.' });
          return;
        }
      }

      // Case B: General Image URL provided
      if (imageUrl && typeof imageUrl === 'string') {
        const trimmedUrl = imageUrl.trim();
        // If already on Kie.ai CDN, return immediately
        if (trimmedUrl.includes('kie.ai') || trimmedUrl.includes('redpandaai.co')) {
          res.json({ success: true, url: trimmedUrl, source: 'kie-cloud' });
          return;
        }

        // If apiKey available, fetch image and upload to Kie.ai cloud
        if (apiKey) {
          try {
            const fetched = await fetch(trimmedUrl);
            if (!fetched.ok) {
              res.status(400).json({ error: `Gagal mengunduh gambar dari tautan luar (HTTP ${fetched.status}).` });
              return;
            }
            const arrayBuffer = await fetched.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);
            const contentType = fetched.headers.get('content-type') || 'image/jpeg';
            const cloudUrl = await uploadToKieCloud(apiKey, buffer, fileName, contentType);
            res.json({ success: true, url: cloudUrl, source: 'kie-cloud' });
            return;
          } catch (err: any) {
            console.warn('URL upload to Kie cloud failed:', err.message);
            res.status(400).json({ error: err.message || 'Gagal memproses gambar dari tautan luar.' });
            return;
          }
        } else {
          // If no API key, return the URL directly
          res.json({ success: true, url: trimmedUrl, source: 'external' });
          return;
        }
      }

      // Case C: Base64 data provided
      if (!base64Data || typeof base64Data !== 'string') {
        res.status(400).json({ error: 'base64Data, imageUrl, atau youtubeUrl diperlukan' });
        return;
      }

      const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      const contentType = matches ? matches[1] : 'image/jpeg';
      const rawData = matches ? matches[2] : base64Data;
      const buffer = Buffer.from(rawData, 'base64');
      const id = `ref_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

      // Store in memory for instant local serving & backup
      uploadedReferences.set(id, { buffer, contentType, fileName });

      // If apiKey exists, upload to Kie.ai official file-base64-upload API
      if (apiKey) {
        try {
          const cloudUrl = await uploadToKieCloud(apiKey, buffer, fileName, contentType);
          res.json({ success: true, url: cloudUrl, source: 'kie-cloud' });
          return;
        } catch (uploadErr: any) {
          console.warn('Kie.ai file-base64-upload failed, falling back to local serving:', uploadErr.message);
          if (uploadErr.message?.includes('API Key Kie.ai tidak valid')) {
            res.status(401).json({ error: uploadErr.message });
            return;
          }
          // Continue to local preview fallback below
        }
      }

      // Fallback: Local preview (will be uploaded automatically when API key is provided during Generate)
      const host = req.get('host') || 'localhost:3000';
      const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
      const ext = contentType.includes('png') ? 'png' : 'jpg';
      const localUrl = `${protocol}://${host}/api/uploaded-reference/${id}.${ext}`;

      res.json({
        success: true,
        url: localUrl,
        source: 'local',
        message: 'Gambar disimpan sementara. Akan otomatis diunggah ke Kie.ai saat API key dimasukkan.',
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memproses gambar referensi' });
    }
  });

  // 2. Check Credits & Validate API Key
  app.get('/api/credit', async (req, res) => {
    try {
      const apiKey = getApiKey(req);
      if (!apiKey) {
        res.status(401).json({ error: 'API key not configured. Provide KIE_AI_API_KEY in environment or app settings.' });
        return;
      }

      const info = await fetchCredit(apiKey);
      if (!info.valid) {
        res.status(400).json({
          valid: false,
          error: info.error,
        });
        return;
      }

      res.json({
        valid: true,
        data: info.raw,
        credit: info.credit,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to check credits' });
    }
  });

  // 2b. Check Multiple API Keys & Credit Balances
  app.post('/api/check-credits', async (req, res) => {
    try {
      const keys = getApiKeys(req);
      if (keys.length === 0) {
        res.status(400).json({ error: 'Tidak ada API key yang dikirimkan.' });
        return;
      }

      const results = await Promise.all(
        keys.map(async (key) => {
          const info = await fetchCredit(key);
          const creditNum = typeof info.credit === 'number' ? info.credit : parseFloat(String(info.credit));
          const isExhausted = info.valid && (creditNum <= 0 || info.credit === '0');
          return {
            key,
            masked: key.length > 10 ? `${key.substring(0, 5)}...${key.substring(key.length - 4)}` : '***',
            valid: info.valid,
            credit: info.credit,
            status: !info.valid ? 'invalid' : isExhausted ? 'exhausted' : 'active',
            error: info.error,
          };
        })
      );

      res.json({ success: true, results });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memeriksa kredit API key' });
    }
  });

  // 3. Create Generation Task with Automatic Multi-Key Failover
  app.post('/api/generate', async (req, res) => {
    try {
      const candidateKeys = getApiKeys(req);
      if (candidateKeys.length === 0) {
        res.status(401).json({
          error: 'No Kie.ai API Key found. Set KIE_AI_API_KEY in your environment or enter your Kie.ai API key in the settings panel.',
        });
        return;
      }

      const {
        prompt,
        aspect_ratio = '1:1',
        quality = 'high',
        background = 'auto',
        model = 'gpt-image-2-5-flare-text-to-image',
        reference_images = [],
      } = req.body;

      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        res.status(400).json({ error: 'Prompt is required and cannot be empty.' });
        return;
      }

      // Filter and clean reference image URLs
      const rawRefImages = Array.isArray(reference_images)
        ? reference_images.filter((u: any) => typeof u === 'string' && u.trim().length > 0)
        : [];

      const failoverLogs: Array<{ keyIndex: number; maskedKey: string; error: string; reason: string }> = [];

      // Loop through candidate keys sequentially until one succeeds
      for (let i = 0; i < candidateKeys.length; i++) {
        const currentKey = candidateKeys[i];
        const masked =
          currentKey.length > 10
            ? `${currentKey.substring(0, 5)}...${currentKey.substring(currentKey.length - 4)}`
            : `Key #${i + 1}`;

        try {
          // Prepare reference images with the current active key
          const validRefImages: string[] = [];
          for (const imgUrl of rawRefImages) {
            const trimmed = imgUrl.trim();

            // 1. If it's a locally stored reference image from our server
            if (trimmed.includes('/api/uploaded-reference/')) {
              const match = trimmed.match(/\/api\/uploaded-reference\/([a-zA-Z0-9_-]+)/);
              const refId = match ? match[1] : null;
              const localItem = refId ? uploadedReferences.get(refId) : null;
              if (localItem) {
                try {
                  const cloudUrl = await uploadToKieCloud(
                    currentKey,
                    localItem.buffer,
                    localItem.fileName,
                    localItem.contentType
                  );
                  validRefImages.push(cloudUrl);
                  continue;
                } catch (upErr: any) {
                  throw upErr;
                }
              }
            }

            // 2. If it's a raw base64 data URI
            if (trimmed.startsWith('data:image/')) {
              const matches = trimmed.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
              if (matches) {
                const contentType = matches[1];
                const buffer = Buffer.from(matches[2], 'base64');
                const cloudUrl = await uploadToKieCloud(currentKey, buffer, 'ref_data.jpg', contentType);
                validRefImages.push(cloudUrl);
                continue;
              }
            }

            // 3. If it's a YouTube video link or Shorts, extract thumbnail
            const ytVideoId = extractYouTubeVideoId(trimmed);
            if (ytVideoId && !trimmed.includes('maxresdefault') && !trimmed.includes('hqdefault')) {
              try {
                const ytThumb = await fetchYouTubeThumbnail(ytVideoId);
                const cloudUrl = await uploadToKieCloud(
                  currentKey,
                  ytThumb.buffer,
                  ytThumb.fileName,
                  ytThumb.contentType
                );
                validRefImages.push(cloudUrl);
                continue;
              } catch (ytErr: any) {
                console.warn('Auto-resolving YouTube thumbnail in createTask failed:', ytErr.message);
              }
            }

            // 4. If it's an external URL (not yet on Kie.ai CDN)
            if (
              trimmed.startsWith('http') &&
              !trimmed.includes('kie.ai') &&
              !trimmed.includes('redpandaai.co')
            ) {
              try {
                const fetched = await fetch(trimmed);
                if (fetched.ok) {
                  const arrayBuffer = await fetched.arrayBuffer();
                  const buffer = Buffer.from(arrayBuffer);
                  const contentType = fetched.headers.get('content-type') || 'image/jpeg';
                  const cloudUrl = await uploadToKieCloud(currentKey, buffer, 'ref_remote.jpg', contentType);
                  validRefImages.push(cloudUrl);
                  continue;
                }
              } catch (fetchErr: any) {
                console.warn('Could not re-upload remote URL to Kie cloud, passing URL directly:', fetchErr.message);
              }
            }

            // 5. URL already on Kie.ai CDN or standard web URL
            validRefImages.push(trimmed);
          }

          // Determine model
          let effectiveModel = model;
          if (validRefImages.length > 0) {
            if (effectiveModel.includes('-text-to-image')) {
              effectiveModel = effectiveModel.replace('-text-to-image', '-image-to-image');
            } else if (!effectiveModel.includes('-image-to-image')) {
              effectiveModel = 'gpt-image-2-5-flare-image-to-image';
            }
          }

          const inputPayload: Record<string, any> = {
            prompt: prompt.trim(),
            aspect_ratio,
            quality,
            background,
          };

          if (validRefImages.length > 0) {
            inputPayload.image_urls = validRefImages;
            inputPayload.image_url = validRefImages[0];
            inputPayload.input_urls = validRefImages;
            inputPayload.input_image = validRefImages[0];
          }

          const requestPayload = {
            model: effectiveModel,
            input: inputPayload,
          };

          const response = await fetch(`${KIE_BASE_URL}/api/v1/jobs/createTask`, {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${currentKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestPayload),
          });

          const responseBodyText = await response.text();
          let responseData: any = {};
          try {
            responseData = JSON.parse(responseBodyText);
          } catch {
            responseData = { raw: responseBodyText };
          }

          if (!response.ok) {
            let errorMsg =
              responseData?.message ||
              responseData?.msg ||
              responseData?.error ||
              `Kie.ai error HTTP ${response.status}: ${responseBodyText}`;

            if (errorMsg.includes('File type not supported')) {
              errorMsg =
                'Format berkas gambar referensi tidak didukung oleh Kie.ai. Pastikan gambar referensi berformat JPG atau PNG dengan ukuran di bawah 10MB.';
            }

            // If credit exhausted or auth error, and there are more keys, fail over!
            if (isCreditOrAuthError(response.status, errorMsg, responseData) && i < candidateKeys.length - 1) {
              failoverLogs.push({
                keyIndex: i,
                maskedKey: masked,
                error: errorMsg,
                reason: 'Credit habis / autentikasi ditolak',
              });
              console.warn(`[Failover] API key ${masked} gagal (${errorMsg}). Otomatis beralih ke key berikutnya...`);
              continue;
            }

            res.status(response.status).json({
              error: errorMsg,
              details: responseData,
              failoverLogs: failoverLogs.length > 0 ? failoverLogs : undefined,
            });
            return;
          }

          // Check if code is not 200 in response payload
          if (responseData.code && responseData.code !== 200) {
            let errorMsg = responseData.message || responseData.msg || 'Kie.ai failed to queue task';
            if (errorMsg.includes('File type not supported')) {
              errorMsg =
                'Format berkas gambar referensi tidak didukung oleh Kie.ai. Pastikan gambar referensi berformat JPG atau PNG dengan ukuran di bawah 10MB.';
            }

            if (isCreditOrAuthError(400, errorMsg, responseData) && i < candidateKeys.length - 1) {
              failoverLogs.push({
                keyIndex: i,
                maskedKey: masked,
                error: errorMsg,
                reason: 'Credit habis / batas kuota tercapai',
              });
              console.warn(`[Failover] API key ${masked} gagal (${errorMsg}). Otomatis beralih ke key berikutnya...`);
              continue;
            }

            res.status(400).json({
              error: errorMsg,
              details: responseData,
              failoverLogs: failoverLogs.length > 0 ? failoverLogs : undefined,
            });
            return;
          }

          // Extract taskId
          const taskId =
            responseData?.data?.taskId ||
            responseData?.data?.id ||
            responseData?.taskId ||
            responseData?.id;

          if (!taskId) {
            res.status(500).json({
              error: 'Did not receive taskId from Kie.ai task creation.',
              details: responseData,
            });
            return;
          }

          // Success!
          res.json({
            success: true,
            taskId,
            status: 'queued',
            model,
            prompt: prompt.trim(),
            aspect_ratio,
            quality,
            usedKey: currentKey,
            usedKeyIndex: i,
            totalKeys: candidateKeys.length,
            failoverOccurred: i > 0,
            failoverLogs: failoverLogs.length > 0 ? failoverLogs : undefined,
          });
          return;
        } catch (attemptErr: any) {
          const errMsg = attemptErr.message || 'Error creating image task';
          if (isCreditOrAuthError(500, errMsg) && i < candidateKeys.length - 1) {
            failoverLogs.push({
              keyIndex: i,
              maskedKey: masked,
              error: errMsg,
              reason: 'Kredit habis atau kesalahan otorisasi',
            });
            console.warn(`[Failover] API key ${masked} exception (${errMsg}). Otomatis beralih ke key berikutnya...`);
            continue;
          }

          if (i === candidateKeys.length - 1) {
            res.status(500).json({
              error: `Gagal membuat task gambar. Error: ${errMsg}`,
              failoverLogs: failoverLogs.length > 0 ? failoverLogs : undefined,
            });
            return;
          }
        }
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Internal error creating image task' });
    }
  });

  // 4. Poll Task Status & Retrieve Output
  app.get('/api/task-status/:taskId', async (req, res) => {
    try {
      const apiKey = getApiKey(req);
      if (!apiKey) {
        res.status(401).json({ error: 'Missing API key' });
        return;
      }

      const { taskId } = req.params;
      if (!taskId) {
        res.status(400).json({ error: 'taskId parameter is required' });
        return;
      }

      const response = await fetch(`${KIE_BASE_URL}/api/v1/jobs/recordInfo?taskId=${encodeURIComponent(taskId)}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      const responseText = await response.text();
      let responseData: any = {};
      try {
        responseData = JSON.parse(responseText);
      } catch {
        responseData = { raw: responseText };
      }

      if (!response.ok) {
        res.status(response.status).json({
          error: responseData?.message || `Failed to fetch task status: HTTP ${response.status}`,
          details: responseData,
        });
        return;
      }

      const taskData = responseData?.data || responseData;
      const state = (taskData?.state || taskData?.status || '').toLowerCase();

      // Check for success state
      if (state === 'success' || state === 'completed' || state === 'done') {
        let resultUrls: string[] = [];

        // Parse resultJson if present
        if (taskData.resultJson) {
          try {
            const parsedJson =
              typeof taskData.resultJson === 'string'
                ? JSON.parse(taskData.resultJson)
                : taskData.resultJson;

            if (Array.isArray(parsedJson?.resultUrls)) {
              resultUrls = parsedJson.resultUrls;
            } else if (Array.isArray(parsedJson?.images)) {
              resultUrls = parsedJson.images;
            } else if (Array.isArray(parsedJson?.output)) {
              resultUrls = parsedJson.output;
            } else if (typeof parsedJson?.url === 'string') {
              resultUrls = [parsedJson.url];
            } else if (typeof parsedJson?.resultUrl === 'string') {
              resultUrls = [parsedJson.resultUrl];
            }
          } catch (e) {
            console.warn('Failed to parse resultJson:', e);
          }
        }

        // Direct resultUrls on taskData
        if (!resultUrls.length && Array.isArray(taskData.resultUrls)) {
          resultUrls = taskData.resultUrls;
        }

        // Check if output is a direct URL or array
        if (!resultUrls.length && typeof taskData.output === 'string') {
          resultUrls = [taskData.output];
        }

        res.json({
          taskId,
          state: 'success',
          isFinished: true,
          resultUrls,
          data: taskData,
        });
        return;
      }

      // Check for failure state
      if (state === 'fail' || state === 'failed' || state === 'error') {
        const failReason =
          taskData?.failReason ||
          taskData?.failMsg ||
          taskData?.errorMessage ||
          responseData?.message ||
          'Image generation failed in Kie.ai.';
        res.json({
          taskId,
          state: 'fail',
          isFinished: true,
          error: failReason,
          data: taskData,
        });
        return;
      }

      // Still in progress: waiting, queuing, generating
      res.json({
        taskId,
        state: state || 'generating',
        isFinished: false,
        progress: taskData?.progress || null,
        data: taskData,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error querying task status' });
    }
  });

  // 5. Proxy Image to bypass CORS and allow high-res direct downloads
  app.get('/api/proxy-image', async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) {
        res.status(400).send('URL query parameter is required');
        return;
      }

      const imageRes = await fetch(url);
      if (!imageRes.ok) {
        res.status(imageRes.status).send('Failed to fetch remote image');
        return;
      }

      const contentType = imageRes.headers.get('content-type') || 'image/png';
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      
      const buffer = Buffer.from(await imageRes.arrayBuffer());
      res.send(buffer);
    } catch (err: any) {
      res.status(500).send(err.message || 'Proxy error');
    }
  });

  // Vite middleware for development vs static files for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
