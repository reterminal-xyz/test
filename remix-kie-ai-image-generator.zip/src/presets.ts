import { AspectRatioOption, QualityOption, ModelOption } from './types';

export const DEFAULT_MODELS: ModelOption[] = [
  {
    id: 'gpt-image-2-5-flare-text-to-image',
    name: 'GPT Image 2.5 Flare',
    badge: 'Recommended',
    description: 'Fastest OpenAI image generation model. 50% lower latency, razor-sharp textures, enhanced prompt adherence.',
  },
  {
    id: 'gpt-image-2-5-sunburst-text-to-image',
    name: 'GPT Image 2.5 Sunburst',
    badge: 'Max Precision',
    description: 'Specialized for complex intricate fine art, architecture, and multi-subject composition.',
  },
  {
    id: 'gpt-image-2-text-to-image',
    name: 'GPT Image 2.0',
    badge: 'Standard',
    description: 'Original OpenAI photorealistic image engine.',
  },
];

export const ASPECT_RATIOS: AspectRatioOption[] = [
  { id: '1:1', label: 'Square (1:1)', width: 1024, height: 1024, icon: 'Square' },
  { id: '16:9', label: 'Landscape (16:9)', width: 1344, height: 768, icon: 'RectangleHorizontal' },
  { id: '9:16', label: 'Story / Reels (9:16)', width: 768, height: 1344, icon: 'RectangleVertical' },
  { id: '4:3', label: 'Standard (4:3)', width: 1152, height: 864, icon: 'LayoutGrid' },
  { id: '3:4', label: 'Editorial (3:4)', width: 864, height: 1152, icon: 'Columns' },
  { id: '3:2', label: 'Photo (3:2)', width: 1216, height: 832, icon: 'Camera' },
  { id: '2:3', label: 'Poster (2:3)', width: 832, height: 1216, icon: 'Film' },
];

export const QUALITIES: QualityOption[] = [
  { id: 'low', label: 'Low', desc: 'Fastest preview generation' },
  { id: 'medium', label: 'Medium', desc: 'Balanced speed & fidelity' },
  { id: 'high', label: 'High', desc: 'Recommended default quality' },
  { id: 'xhigh', label: 'Extra High', desc: 'Refined textures & reflections' },
  { id: 'max', label: 'Max (4K)', desc: 'Ultimate fine-grained resolution' },
];

export interface PromptPreset {
  title: string;
  category: string;
  prompt: string;
  aspect_ratio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '3:2' | '2:3';
  background?: 'auto' | 'opaque' | 'transparent';
}

export const PROMPT_PRESETS: PromptPreset[] = [
  {
    category: 'Photorealism',
    title: 'Minimalist Architecture',
    prompt: 'Ultra-modern concrete pavilion perched on a cliff at golden hour, floor-to-ceiling glass reflections, serene reflecting pool, warm interior lighting, photorealistic 8k architectural photography.',
    aspect_ratio: '16:9',
  },
  {
    category: 'Product Mockup',
    title: 'Glass Perfume Bottle',
    prompt: 'Luxury frosted amber glass perfume bottle with minimalist gold typography, sitting on a smooth raw travertine pedestal, soft diffused studio lighting, water droplets, isolated on pure transparent background.',
    aspect_ratio: '1:1',
    background: 'transparent',
  },
  {
    category: 'Portrait',
    title: 'Cyberpunk Neon Street',
    prompt: 'Cinematic medium shot of a young cyberpunk courier in a reflective transparent iridescent raincoat, drenched under neon rain in Shinjuku alleys, dramatic rim lighting, vibrant cyan and magenta hues, shallow depth of field, 35mm lens.',
    aspect_ratio: '3:4',
  },
  {
    category: 'Digital Art',
    title: 'Floating Island Sanctuary',
    prompt: 'Enchanted floating archipelago with ancient Japanese cherry blossom temples, gentle cascading waterfalls spilling into clouds, ethereal sun rays breaking through mist, vibrant Studio Ghibli inspired concept art.',
    aspect_ratio: '16:9',
  },
  {
    category: '3D Render',
    title: 'Retro Futuristic Gadget',
    prompt: 'Isometric 3D render of a cute retro-futuristic holographic synthesizer device with tactile pastel buttons and glowing vacuum tubes, matte clay finish, playful industrial design, clean studio shadow.',
    aspect_ratio: '1:1',
  },
  {
    category: 'Nature',
    title: 'Macro Dewdrop Forest',
    prompt: 'Macro shot of a glowing translucent mushroom cap deep in an autumn moss forest, tiny crystal dewdrop reflecting the canopy above, soft morning mist, natural bokeh, National Geographic style.',
    aspect_ratio: '9:16',
  },
];

export const STYLE_MODIFIERS = [
  { label: 'Studio Lighting', suffix: ', professional studio strobe lighting, crisp highlights, 8k commercial photography' },
  { label: 'Cinematic 35mm', suffix: ', cinematic film still, shot on 35mm Arri Alexa, anamorphic lens flare, moody color grading' },
  { label: 'Transparent BG', suffix: ', isolated on clean transparent background, clean edges, studio product asset' },
  { label: 'Octane 3D', suffix: ', 3D rendered in Octane, raytraced reflections, volumetric fog, intricate sub-surface scattering' },
  { label: 'Minimalist Clean', suffix: ', minimalist composition, neutral tone background, high-end editorial aesthetic' },
  { label: 'Cyberpunk Glow', suffix: ', dark cyberpunk atmosphere, vibrant neon edge lights, rain-slicked reflective surfaces' },
  { label: 'Anime Concept', suffix: ', Makoto Shinkai aesthetic, luminous clouds, rich color depth, emotional atmosphere' },
];
