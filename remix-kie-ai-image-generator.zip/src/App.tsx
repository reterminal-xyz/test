import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { PromptInput } from './components/PromptInput';
import { ReferenceImageInput } from './components/ReferenceImageInput';
import { ModelSettings } from './components/ModelSettings';
import { ImageResult } from './components/ImageResult';
import { ImageModal } from './components/ImageModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { ApiKeyModal } from './components/ApiKeyModal';
import {
  AspectRatioId,
  QualityTier,
  BackgroundMode,
  GeneratedImageItem,
  ServerConfig,
  ReferenceImageItem,
  ApiKeyEntry,
  GeminiApiKeyEntry,
} from './types';
import { PromptPreset, DEFAULT_MODELS } from './presets';
import { Zap, ShieldCheck, Cpu, Image as ImageIcon, AlertTriangle, CheckCircle2, ArrowRight, X } from 'lucide-react';

export default function App() {
  // Configuration state from server
  const [serverConfig, setServerConfig] = useState<ServerConfig>({
    hasServerKey: false,
    defaultModel: 'gpt-image-2-5-flare-text-to-image',
    supportedModels: DEFAULT_MODELS,
    aspectRatios: [],
    qualities: [],
  });

  // Multiple API keys state (stored in localStorage & sessionStorage for maximum persistence)
  const [apiKeys, setApiKeys] = useState<ApiKeyEntry[]>(() => {
    try {
      const savedList = localStorage.getItem('kie_ai_api_keys') || sessionStorage.getItem('kie_ai_api_keys');
      if (savedList) {
        const parsed = JSON.parse(savedList);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      // Backward compatibility with previous single key
      const legacy = localStorage.getItem('kie_ai_api_key') || sessionStorage.getItem('kie_ai_api_key');
      if (legacy && legacy.trim()) {
        return [
          {
            id: `key_${Date.now()}`,
            name: 'API Key #1 (Utama)',
            key: legacy.trim(),
            status: 'unknown',
          },
        ];
      }
      return [];
    } catch {
      return [];
    }
  });

  // Primary API key helper
  const primaryApiKey = apiKeys.length > 0 ? apiKeys[0].key : '';

  // Credit balance info for primary key
  const [creditInfo, setCreditInfo] = useState<{ valid?: boolean; balance?: number | string; raw?: any } | null>(null);
  const [checkingCredit, setCheckingCredit] = useState(false);

  // Active failover notification banner
  const [failoverNotification, setFailoverNotification] = useState<{
    message: string;
    fromKey?: string;
    toKey?: string;
    reason?: string;
  } | null>(null);

  // Generation parameters
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioId>('1:1');
  const [quality, setQuality] = useState<QualityTier>('high');
  const [background, setBackground] = useState<BackgroundMode>('auto');
  const [model, setModel] = useState('gpt-image-2-5-flare-text-to-image');
  const [referenceImages, setReferenceImages] = useState<ReferenceImageItem[]>([]);

  // Generation execution state
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState('');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [currentImage, setCurrentImage] = useState<GeneratedImageItem | null>(null);
  const [error, setError] = useState<string | null>(null);

  // History & Modals
  const [history, setHistory] = useState<GeneratedImageItem[]>(() => {
    try {
      const saved = localStorage.getItem('kie_ai_image_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [apiKeyModalTab, setApiKeyModalTab] = useState<'kie' | 'gemini'>('kie');
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [lightboxItem, setLightboxItem] = useState<GeneratedImageItem | null>(null);

  // Gemini API Key Management (User custom keys + Saved list)
  const [geminiApiKey, setGeminiApiKey] = useState<string>(() => {
    try {
      return localStorage.getItem('gemini_api_key') || sessionStorage.getItem('gemini_api_key') || '';
    } catch {
      return '';
    }
  });

  const [savedGeminiKeys, setSavedGeminiKeys] = useState<GeminiApiKeyEntry[]>(() => {
    try {
      const saved = localStorage.getItem('saved_gemini_api_keys') || sessionStorage.getItem('saved_gemini_api_keys');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleOpenApiKeyModal = (tab: 'kie' | 'gemini' = 'kie') => {
    setApiKeyModalTab(tab);
    setIsApiKeyModalOpen(true);
  };

  // Interval timers
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const pollRef = useRef<NodeJS.Timeout | null>(null);

  // 1. Fetch server configuration on mount
  useEffect(() => {
    fetch('/api/config')
      .then((res) => res.json())
      .then((data: ServerConfig) => {
        setServerConfig(data);
        if (data.defaultModel) {
          setModel(data.defaultModel);
        }
      })
      .catch((err) => console.warn('Failed to load server config:', err));
  }, []);

  // Save apiKeys to localStorage & sessionStorage
  useEffect(() => {
    try {
      localStorage.setItem('kie_ai_api_keys', JSON.stringify(apiKeys));
      sessionStorage.setItem('kie_ai_api_keys', JSON.stringify(apiKeys));
      if (apiKeys.length > 0) {
        localStorage.setItem('kie_ai_api_key', apiKeys[0].key);
        sessionStorage.setItem('kie_ai_api_key', apiKeys[0].key);
      } else {
        localStorage.removeItem('kie_ai_api_key');
        sessionStorage.removeItem('kie_ai_api_key');
      }
    } catch (e) {
      console.warn('Failed to persist API keys to storage:', e);
    }
  }, [apiKeys]);

  // Save Gemini keys to localStorage & sessionStorage
  useEffect(() => {
    try {
      if (geminiApiKey && geminiApiKey.trim()) {
        localStorage.setItem('gemini_api_key', geminiApiKey.trim());
        sessionStorage.setItem('gemini_api_key', geminiApiKey.trim());
      } else {
        localStorage.removeItem('gemini_api_key');
        sessionStorage.removeItem('gemini_api_key');
      }
    } catch (e) {
      console.warn('Failed to persist gemini_api_key to storage:', e);
    }
  }, [geminiApiKey]);

  useEffect(() => {
    try {
      localStorage.setItem('saved_gemini_api_keys', JSON.stringify(savedGeminiKeys));
      sessionStorage.setItem('saved_gemini_api_keys', JSON.stringify(savedGeminiKeys));
    } catch (e) {
      console.warn('Failed to persist saved_gemini_api_keys to storage:', e);
    }
  }, [savedGeminiKeys]);

  // 2. Fetch initial credits if key is available
  useEffect(() => {
    if (serverConfig.hasServerKey || apiKeys.length > 0) {
      checkAllCredits();
    }
  }, [serverConfig.hasServerKey, apiKeys.length]);

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('kie_ai_image_history', JSON.stringify(history.slice(0, 30)));
    } catch {
      // storage full
    }
  }, [history]);

  // Check single key credit
  const checkSingleKeyCredit = async (keyToTest: string) => {
    const trimmed = keyToTest.trim();
    if (!trimmed) {
      return { success: false, message: 'API key tidak boleh kosong.' };
    }

    try {
      const res = await fetch('/api/credit', {
        headers: {
          Authorization: `Bearer ${trimmed}`,
        },
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        const bal = data.credit !== undefined ? data.credit : 'Active';
        return {
          success: true,
          message: `Koneksi berhasil! Sisa kredit: ${bal}`,
          balance: bal,
        };
      } else {
        return {
          success: false,
          message: data.error || 'Gagal memvalidasi API key.',
        };
      }
    } catch (e: any) {
      return {
        success: false,
        message: e.message || 'Gagal menghubungi server.',
      };
    }
  };

  // Check all configured keys credits via /api/check-credits
  const checkAllCredits = async () => {
    if (apiKeys.length === 0 && !serverConfig.hasServerKey) return;
    setCheckingCredit(true);

    try {
      const candidateKeys = apiKeys.map((k) => k.key);
      const res = await fetch('/api/check-credits', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(candidateKeys.length > 0 ? { 'x-api-keys': JSON.stringify(candidateKeys) } : {}),
        },
        body: JSON.stringify({ apiKeys: candidateKeys }),
      });

      const data = await res.json();
      if (res.ok && Array.isArray(data.results)) {
        const resultsMap = new Map<string, any>();
        data.results.forEach((item: any) => {
          resultsMap.set(item.key, item);
        });

        setApiKeys((prev) =>
          prev.map((k) => {
            const found = resultsMap.get(k.key);
            if (found) {
              return {
                ...k,
                credit: found.credit,
                status: found.status,
                lastChecked: Date.now(),
                error: found.error,
              };
            }
            return k;
          })
        );

        // Update creditInfo for the top active key
        if (data.results.length > 0) {
          const first = data.results[0];
          setCreditInfo({
            valid: first.valid,
            balance: first.credit,
          });
        }
      }
    } catch (err: any) {
      console.warn('Failed to check all credits:', err);
    } finally {
      setCheckingCredit(false);
    }
  };

  const handleUpdateApiKeys = (updatedKeys: ApiKeyEntry[]) => {
    setApiKeys(updatedKeys);
    if (updatedKeys.length > 0 && updatedKeys[0].credit !== undefined) {
      setCreditInfo({
        valid: updatedKeys[0].status !== 'invalid',
        balance: updatedKeys[0].credit,
      });
    }
  };

  // Preset Selection
  const handleSelectPreset = (preset: PromptPreset) => {
    setPrompt(preset.prompt);
    setAspectRatio(preset.aspect_ratio);
    if (preset.background) {
      setBackground(preset.background);
    }
  };

  // Append Style Modifier
  const handleApplyStyleModifier = (modifier: string) => {
    setPrompt((prev) => {
      const trimmed = prev.trim();
      if (!trimmed) return modifier.replace(/^,\s*/, '');
      if (trimmed.endsWith(',')) return `${trimmed} ${modifier.replace(/^,\s*/, '')}`;
      return `${trimmed}${modifier}`;
    });
  };

  // Re-use prompt & settings from history or lightbox
  const handleUseSettings = (p: string, aspect: AspectRatioId, q: QualityTier, bg: BackgroundMode) => {
    setPrompt(p);
    if (aspect) setAspectRatio(aspect);
    if (q) setQuality(q);
    if (bg) setBackground(bg);
  };

  // Reference image handlers
  const handleAddReferenceImage = (item: ReferenceImageItem) => {
    setReferenceImages((prev) => (prev.length < 3 ? [...prev, item] : prev));
  };

  const handleRemoveReferenceImage = (id: string) => {
    setReferenceImages((prev) => prev.filter((img) => img.id !== id));
  };

  const handleClearAllReferences = () => {
    setReferenceImages([]);
  };

  const handleUseAsReference = (imageUrl: string, promptText?: string) => {
    const newItem: ReferenceImageItem = {
      id: `ref_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      url: imageUrl,
      previewUrl: imageUrl,
      name: 'Selected Image',
    };
    setReferenceImages([newItem]);
    if (promptText && !prompt.trim()) {
      setPrompt(promptText);
    }
  };

  // Stop polling and timer
  const cleanupTimers = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (pollRef.current) clearTimeout(pollRef.current);
    timerRef.current = null;
    pollRef.current = null;
  };

  // Generate Image Flow with Multi-Key Auto Failover
  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    // Check if at least one key is present or server key exists
    if (!serverConfig.hasServerKey && apiKeys.length === 0) {
      setIsApiKeyModalOpen(true);
      setError('Harap masukkan minimal 1 Kie.ai API Key untuk mulai membuat gambar.');
      return;
    }

    cleanupTimers();
    setError(null);
    setIsGenerating(true);
    setGenerationStep('Mengirim task ke antrean Kie.ai...');
    setElapsedSeconds(0);

    const startTime = Date.now();

    // Start elapsed timer
    timerRef.current = setInterval(() => {
      setElapsedSeconds((s) => s + 1);
    }, 1000);

    try {
      const candidateKeyStrings = apiKeys.map((k) => k.key);

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (candidateKeyStrings.length > 0) {
        headers['Authorization'] = `Bearer ${candidateKeyStrings[0]}`;
        headers['x-api-keys'] = JSON.stringify(candidateKeyStrings);
      }

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspect_ratio: aspectRatio,
          quality,
          background,
          model,
          reference_images: referenceImages.map((img) => img.url),
          apiKeys: candidateKeyStrings,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.taskId) {
        // If failover occurred and all keys exhausted
        if (data.failoverLogs && data.failoverLogs.length > 0) {
          // Mark exhausted keys
          setApiKeys((prev) =>
            prev.map((k, idx) => {
              if (idx < data.failoverLogs.length) {
                return { ...k, status: 'exhausted', credit: 0 };
              }
              return k;
            })
          );
        }
        throw new Error(data.error || 'Gagal mengirimkan task pembuatan gambar.');
      }

      // Check if automatic failover occurred
      if (data.failoverOccurred) {
        const usedIdx = data.usedKeyIndex ?? 1;
        const previousKeyName = apiKeys[0]?.name || 'Key #1 (Utama)';
        const activeKeyName = apiKeys[usedIdx]?.name || `Key #${usedIdx + 1}`;

        setFailoverNotification({
          message: `Kredit pada ${previousKeyName} habis. Sistem otomatis beralih dan sukses menggunakan ${activeKeyName}!`,
          fromKey: previousKeyName,
          toKey: activeKeyName,
        });

        // Mark the previous key(s) as exhausted
        setApiKeys((prev) =>
          prev.map((k, idx) => {
            if (idx < usedIdx) {
              return { ...k, status: 'exhausted', credit: 0 };
            }
            return k;
          })
        );
      }

      const taskId = data.taskId;
      const keyUsedForPolling = data.usedKey || primaryApiKey;

      setGenerationStep(
        referenceImages.length > 0
          ? 'Task masuk antrean. Model GPT-Image 2.5 Flare menerapkan panduan gambar referensi...'
          : 'Task masuk antrean. Mempersiapkan sintesis GPT-Image 2.5 Flare...'
      );

      // Start polling for completion
      pollTask(taskId, startTime, keyUsedForPolling);
    } catch (err: any) {
      cleanupTimers();
      setIsGenerating(false);
      setError(err.message || 'Terjadi kesalahan saat memulai pembuatan gambar.');
    }
  };

  // Polling loop with exponential/paced intervals
  const pollTask = (taskId: string, startTime: number, activeKey: string) => {
    let attempts = 0;
    const maxAttempts = 60; // Up to ~120s

    const checkStatus = async () => {
      attempts++;
      try {
        const headers: Record<string, string> = {};
        if (activeKey) {
          headers['Authorization'] = `Bearer ${activeKey}`;
        }

        const res = await fetch(`/api/task-status/${encodeURIComponent(taskId)}`, { headers });
        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || 'Gagal mengecek status task');
        }

        if (data.isFinished) {
          cleanupTimers();
          setIsGenerating(false);

          if (data.state === 'success' && data.resultUrls && data.resultUrls.length > 0) {
            const finalUrl = data.resultUrls[0];
            const durationMs = Date.now() - startTime;

            const newItem: GeneratedImageItem = {
              id: `${taskId}_${Date.now()}`,
              taskId,
              url: finalUrl,
              prompt: prompt.trim(),
              aspect_ratio: aspectRatio,
              quality,
              background,
              model,
              createdAt: Date.now(),
              durationMs,
              reference_images: referenceImages.map((img) => img.url),
            };

            setCurrentImage(newItem);
            setHistory((prev) => [newItem, ...prev]);

            // Refresh credit balance of all keys in background
            checkAllCredits();
          } else {
            setError(data.error || 'Sintesis gambar selesai tetapi tidak menghasilkan URL gambar yang valid.');
          }
          return;
        }

        // Still in progress
        const state = (data.state || '').toLowerCase();
        if (state === 'queuing' || state === 'waiting') {
          setGenerationStep('Menunggu giliran pada antrean GPU Kie.ai...');
        } else if (state === 'generating') {
          setGenerationStep('GPT-Image 2.5 Flare sedang merender tekstur dan detail pencahayaan...');
        } else {
          setGenerationStep(`Sedang memproses task (${state || 'working'})...`);
        }

        if (attempts >= maxAttempts) {
          cleanupTimers();
          setIsGenerating(false);
          setError('Pembuatan gambar melebihi batas waktu 2 menit. Task mungkin masih berjalan di server Kie.ai.');
          return;
        }

        // Schedule next poll in 2.2 seconds
        pollRef.current = setTimeout(checkStatus, 2200);
      } catch (err: any) {
        cleanupTimers();
        setIsGenerating(false);
        setError(err.message || 'Gagal mengecek status task');
      }
    };

    // First check after 1.5 seconds
    pollRef.current = setTimeout(checkStatus, 1500);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-400/30 selection:text-amber-200">
      {/* Top Navigation */}
      <Navbar
        hasServerKey={serverConfig.hasServerKey}
        apiKeys={apiKeys}
        onOpenApiKeyModal={handleOpenApiKeyModal}
        onToggleHistory={() => setIsHistoryOpen((open) => !open)}
        historyCount={history.length}
        creditInfo={creditInfo}
        checkingCredit={checkingCredit}
        geminiApiKey={geminiApiKey}
        hasServerGeminiKey={serverConfig.hasServerGeminiKey}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Failover Alert Banner (Automatic Key Rotation Notification) */}
        {failoverNotification && (
          <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-200 flex items-center justify-between gap-3 animate-in slide-in-from-top duration-200 shadow-lg shadow-amber-950/20">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div className="text-xs sm:text-sm">
                <p className="font-semibold text-amber-300">Pengalihan API Key Otomatis (Failover Aktif)</p>
                <p className="text-amber-300/80 mt-0.5">{failoverNotification.message}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleOpenApiKeyModal('kie')}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-400 text-zinc-950 hover:bg-amber-300 transition-colors whitespace-nowrap"
              >
                Lihat Sisa Kredit
              </button>
              <button
                onClick={() => setFailoverNotification(null)}
                className="p-1 rounded-lg text-amber-400 hover:text-amber-200 hover:bg-amber-900/40 transition-colors"
                title="Tutup pemberitahuan"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Model Highlight Hero Banner */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-900 border border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                Next-Gen Image Generation
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              OpenAI GPT-Image 2.5 Flare
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 max-w-2xl leading-relaxed">
              Didukung Kie.ai Market API dengan fitur <strong>Multi-API Key & Failover Otomatis</strong>. Sistem otomatis beralih ke key cadangan saat kredit habis tanpa menghentikan proses generasi.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-300">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Multi-Key Failover</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Reference Fidelity</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800">
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>4K Max Tiers</span>
            </div>
          </div>
        </div>

        {/* Top Section: Prompt Input & Generation Parameters side-by-side */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* Left Column: Describe Image Edits & Transformation */}
          <div className="w-full">
            <PromptInput
              prompt={prompt}
              onChangePrompt={setPrompt}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
              onSelectPreset={handleSelectPreset}
              onApplyStyleModifier={handleApplyStyleModifier}
              hasReferenceImage={referenceImages.length > 0}
              geminiApiKey={geminiApiKey}
              hasServerGeminiKey={serverConfig.hasServerGeminiKey}
              onOpenApiKeyModal={handleOpenApiKeyModal}
            />
          </div>

          {/* Right Column: Generation Parameters */}
          <div className="w-full">
            <ModelSettings
              model={model}
              onChangeModel={setModel}
              aspectRatio={aspectRatio}
              onChangeAspectRatio={setAspectRatio}
              quality={quality}
              onChangeQuality={setQuality}
              background={background}
              onChangeBackground={setBackground}
              supportedModels={serverConfig.supportedModels}
            />
          </div>
        </section>

        {/* Bottom Section: Reference Images & Generated Result side-by-side */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* Left Column: Gambar Referensi */}
          <div className="w-full">
            <ReferenceImageInput
              referenceImages={referenceImages}
              onAddReferenceImage={handleAddReferenceImage}
              onRemoveReferenceImage={handleRemoveReferenceImage}
              onClearAll={handleClearAllReferences}
              userApiKey={primaryApiKey}
            />
          </div>

          {/* Right Column: Hasil Gambar (Image Result) */}
          <div className="w-full">
            <div className="sticky top-20">
              <ImageResult
                isGenerating={isGenerating}
                generationStep={generationStep}
                elapsedSeconds={elapsedSeconds}
                currentImage={currentImage}
                error={error}
                onOpenLightbox={(item) => setLightboxItem(item)}
                onRetry={handleGenerate}
                onUseAsReference={handleUseAsReference}
              />
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-zinc-950 py-6 text-center text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            Connected to{' '}
            <a
              href="https://docs.kie.ai/market/gpt/gpt-image-2-5-flare-text-to-image"
              target="_blank"
              rel="noreferrer"
              className="text-zinc-400 hover:text-amber-400 underline"
            >
              Kie.ai GPT-Image 2.5 Flare Market API
            </a>
          </p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsApiKeyModalOpen(true)}
              className="hover:text-zinc-300 transition-colors"
            >
              Kelola API Key ({apiKeys.length})
            </button>
            <span>•</span>
            <button
              onClick={() => setIsHistoryOpen(true)}
              className="hover:text-zinc-300 transition-colors"
            >
              Session Gallery ({history.length})
            </button>
          </div>
        </div>
      </footer>

      {/* Modals and Drawers */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        apiKeys={apiKeys}
        onUpdateApiKeys={handleUpdateApiKeys}
        hasServerKey={serverConfig.hasServerKey}
        onTestSingleKey={checkSingleKeyCredit}
        onCheckAllCredits={checkAllCredits}
        checkingCredits={checkingCredit}
        geminiApiKey={geminiApiKey}
        onUpdateGeminiApiKey={setGeminiApiKey}
        savedGeminiKeys={savedGeminiKeys}
        onUpdateSavedGeminiKeys={setSavedGeminiKeys}
        hasServerGeminiKey={serverConfig.hasServerGeminiKey}
        initialTab={apiKeyModalTab}
      />

      <ImageModal
        item={lightboxItem}
        onClose={() => setLightboxItem(null)}
        onUsePrompt={handleUseSettings}
        onUseAsReference={handleUseAsReference}
      />

      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        items={history}
        onSelectItem={(item) => {
          setCurrentImage(item);
          handleUseSettings(item.prompt, item.aspect_ratio, item.quality, item.background);
        }}
        onClearHistory={() => {
          setHistory([]);
          localStorage.removeItem('kie_ai_image_history');
        }}
        onUseAsReference={handleUseAsReference}
      />
    </div>
  );
}
