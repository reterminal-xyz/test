export type AspectRatioId = '1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '3:2' | '2:3';

export type QualityTier = 'low' | 'medium' | 'high' | 'xhigh' | 'max';

export type BackgroundMode = 'auto' | 'opaque' | 'transparent';

export interface ModelOption {
  id: string;
  name: string;
  badge: string;
  description: string;
}

export interface AspectRatioOption {
  id: AspectRatioId;
  label: string;
  width: number;
  height: number;
  icon: string;
}

export interface QualityOption {
  id: QualityTier;
  label: string;
  desc: string;
}

export interface ReferenceImageItem {
  id: string;
  url: string;
  previewUrl?: string;
  name?: string;
  size?: number;
}

export interface GenerationParams {
  prompt: string;
  aspect_ratio: AspectRatioId;
  quality: QualityTier;
  background: BackgroundMode;
  model: string;
  reference_images?: string[];
}

export interface GeneratedImageItem {
  id: string;
  taskId: string;
  url: string;
  prompt: string;
  aspect_ratio: AspectRatioId;
  quality: QualityTier;
  background: BackgroundMode;
  model: string;
  createdAt: number;
  durationMs?: number;
  reference_images?: string[];
}

export interface ServerConfig {
  hasServerKey: boolean;
  hasGeminiKey?: boolean;
  geminiModel?: string;
  defaultModel: string;
  supportedModels: ModelOption[];
  aspectRatios: AspectRatioOption[];
  qualities: QualityOption[];
}

export type PromptEnhanceStyle = 'photorealistic' | 'creative' | 'anime' | 'clarity' | 'auto';

export interface EnhancePromptRequest {
  prompt: string;
  style?: PromptEnhanceStyle;
  hasReferenceImage?: boolean;
  geminiApiKey?: string;
}

export interface EnhancePromptResponse {
  success: boolean;
  enhancedPrompt?: string;
  originalPrompt?: string;
  modelUsed?: string;
  error?: string;
  missingKey?: boolean;
}

export interface ApiKeyEntry {
  id: string;
  name: string;
  key: string;
  credit?: number | string;
  status?: 'active' | 'exhausted' | 'invalid' | 'unknown';
  lastChecked?: number;
  error?: string;
}

export interface GeminiApiKeyEntry {
  id: string;
  name: string;
  key: string;
  status?: 'active' | 'invalid' | 'unknown';
  lastChecked?: number;
  error?: string;
}
