import React, { useState } from 'react';
import {
  Download,
  Maximize2,
  Copy,
  Check,
  Sparkles,
  Clock,
  Layers,
  AlertCircle,
  RefreshCw,
  Share2,
  ExternalLink,
  ImagePlus,
} from 'lucide-react';
import { GeneratedImageItem } from '../types';

interface ImageResultProps {
  isGenerating: boolean;
  generationStep: string;
  elapsedSeconds: number;
  currentImage: GeneratedImageItem | null;
  error: string | null;
  onOpenLightbox: (item: GeneratedImageItem) => void;
  onRetry: () => void;
  onUseAsReference?: (imageUrl: string, prompt?: string) => void;
}

export const ImageResult: React.FC<ImageResultProps> = ({
  isGenerating,
  generationStep,
  elapsedSeconds,
  currentImage,
  error,
  onOpenLightbox,
  onRetry,
  onUseAsReference,
}) => {
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleCopyPrompt = async () => {
    if (!currentImage) return;
    try {
      await navigator.clipboard.writeText(currentImage.prompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const handleDownload = async () => {
    if (!currentImage?.url) return;
    setDownloading(true);
    try {
      // Use proxy to avoid CORS download issues
      const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(currentImage.url)}`;
      const res = await fetch(proxyUrl);
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      const cleanPrompt = currentImage.prompt
        .slice(0, 30)
        .replace(/[^a-zA-Z0-9]/g, '_')
        .toLowerCase();
      a.download = `kie-ai-flare_${cleanPrompt}_${currentImage.aspect_ratio}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
    } catch (e) {
      // Fallback: direct window open
      window.open(currentImage.url, '_blank');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl shadow-black/40">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-200">
            Generated Output
          </h2>
        </div>
        {currentImage && !isGenerating && (
          <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-mono">
            <Clock className="w-3.5 h-3.5 text-zinc-400" />
            <span>
              {currentImage.durationMs ? `${(currentImage.durationMs / 1000).toFixed(1)}s` : 'Completed'}
            </span>
          </div>
        )}
      </div>

      {/* State 1: Generating Loader */}
      {isGenerating && (
        <div className="min-h-[400px] flex flex-col items-center justify-center p-8 rounded-xl border border-zinc-800/80 bg-zinc-950/60 relative overflow-hidden">
          {/* Animated subtle backdrop */}
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 via-transparent to-transparent pointer-events-none" />

          {/* Center pulsating orb */}
          <div className="relative mb-6">
            <div className="w-20 h-20 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center animate-pulse">
              <Sparkles className="w-9 h-9 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <div className="absolute -inset-1 rounded-2xl bg-amber-400/20 blur-lg -z-10 animate-pulse" />
          </div>

          <h3 className="text-base font-medium text-zinc-100 mb-1">
            Synthesizing with GPT-Image 2.5 Flare
          </h3>
          <p className="text-xs text-zinc-400 mb-4 max-w-sm text-center">
            {generationStep || 'OpenAI Flare model processing your prompt with high-fidelity textures...'}
          </p>

          {/* Timer and steps */}
          <div className="flex items-center gap-3 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-xs font-mono text-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Elapsed: {elapsedSeconds}s</span>
          </div>

          <div className="w-48 h-1.5 bg-zinc-800 rounded-full mt-5 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full animate-indeterminate" />
          </div>
        </div>
      )}

      {/* State 2: Error Card */}
      {!isGenerating && error && (
        <div className="min-h-[300px] flex flex-col items-center justify-center p-6 rounded-xl border border-rose-900/40 bg-rose-950/20 text-center">
          <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-semibold text-rose-200 mb-1">Generation Failed</h3>
          <p className="text-xs text-rose-300/80 max-w-md mb-4 leading-relaxed font-mono">
            {error}
          </p>
          <button
            id="retry-generation-btn"
            onClick={onRetry}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-rose-500/20 text-rose-200 hover:bg-rose-500/30 border border-rose-500/40 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry Generation</span>
          </button>
        </div>
      )}

      {/* State 3: Active Generated Image Display */}
      {!isGenerating && !error && currentImage && (
        <div className="space-y-4">
          {/* Image Display Frame with Checkerboard for transparent backgrounds */}
          <div className="relative group rounded-xl border border-zinc-800 overflow-hidden bg-zinc-950 flex items-center justify-center">
            {/* Checkerboard pattern for transparent images */}
            {currentImage.background === 'transparent' && (
              <div
                className="absolute inset-0 opacity-15"
                style={{
                  backgroundImage:
                    'radial-gradient(#ffffff 1px, transparent 1px), radial-gradient(#ffffff 1px, #18181b 1px)',
                  backgroundSize: '20px 20px',
                  backgroundPosition: '0 0, 10px 10px',
                }}
              />
            )}

            <img
              id="active-generated-image"
              src={currentImage.url}
              alt={currentImage.prompt}
              referrerPolicy="no-referrer"
              className="w-full max-h-[580px] object-contain cursor-pointer relative z-10 transition-transform duration-300 group-hover:scale-[1.01]"
              onClick={() => onOpenLightbox(currentImage)}
            />

            {/* Hover overlay with zoom button */}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity z-20 flex items-center justify-center pointer-events-none">
              <button
                type="button"
                className="px-4 py-2 rounded-xl bg-zinc-900/90 text-zinc-100 text-xs font-medium border border-zinc-700 flex items-center gap-1.5 shadow-lg pointer-events-auto"
                onClick={() => onOpenLightbox(currentImage)}
              >
                <Maximize2 className="w-3.5 h-3.5 text-amber-400" />
                <span>View Full Resolution</span>
              </button>
            </div>
          </div>

          {/* Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-2">
              <button
                id="download-image-btn"
                type="button"
                onClick={handleDownload}
                disabled={downloading}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-amber-400 text-zinc-950 hover:bg-amber-300 transition-all shadow-md shadow-amber-950/30"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{downloading ? 'Downloading...' : 'Download HD'}</span>
              </button>

              <button
                id="copy-prompt-btn"
                type="button"
                onClick={handleCopyPrompt}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-colors"
                title="Copy prompt text"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Prompt'}</span>
              </button>

              {onUseAsReference && (
                <button
                  id="use-as-reference-btn"
                  type="button"
                  onClick={() => onUseAsReference(currentImage.url, currentImage.prompt)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors"
                  title="Gunakan gambar ini sebagai referensi untuk generasi berikutnya"
                >
                  <ImagePlus className="w-3.5 h-3.5" />
                  <span>Jadikan Referensi</span>
                </button>
              )}

              <a
                id="open-source-url-link"
                href={currentImage.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Open URL</span>
              </a>
            </div>

            {/* Quick Metadata tags */}
            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="px-2 py-0.5 rounded-md bg-zinc-800 text-zinc-300 border border-zinc-700 font-mono">
                {currentImage.aspect_ratio}
              </span>
              <span className="px-2 py-0.5 rounded-md bg-zinc-800 text-zinc-300 border border-zinc-700 uppercase">
                {currentImage.quality}
              </span>
              {currentImage.background === 'transparent' && (
                <span className="px-2 py-0.5 rounded-md bg-amber-950/40 text-amber-300 border border-amber-800/40 font-medium">
                  Transparent
                </span>
              )}
            </div>
          </div>

          {/* Full Prompt Display Box */}
          <div className="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800/80 text-xs text-zinc-300 leading-relaxed font-sans">
            <span className="text-zinc-500 font-medium mr-1.5">Prompt:</span>
            {currentImage.prompt}
          </div>
        </div>
      )}

      {/* State 4: Initial Empty State */}
      {!isGenerating && !error && !currentImage && (
        <div className="min-h-[380px] flex flex-col items-center justify-center p-8 rounded-xl border border-dashed border-zinc-800 bg-zinc-950/40 text-center">
          <div className="w-16 h-16 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-center text-zinc-500 mb-4">
            <Sparkles className="w-7 h-7 text-zinc-500" />
          </div>
          <h3 className="text-sm font-semibold text-zinc-300 mb-1">
            Ready to Generate
          </h3>
          <p className="text-xs text-zinc-500 max-w-sm leading-relaxed mb-4">
            Type your prompt above or click one of the sample prompt presets to synthesize high-quality visuals using Kie.ai's GPT-Image 2.5 Flare model.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] text-zinc-400">
            <span className="px-2 py-1 rounded bg-zinc-900 border border-zinc-800">⚡ 50% Lower Latency</span>
            <span className="px-2 py-1 rounded bg-zinc-900 border border-zinc-800">🎯 Ultra-High Prompt Fidelity</span>
            <span className="px-2 py-1 rounded bg-zinc-900 border border-zinc-800">✨ Transparent BG Support</span>
          </div>
        </div>
      )}
    </div>
  );
};
