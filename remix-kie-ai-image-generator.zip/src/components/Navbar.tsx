import React from 'react';
import { Sparkles, Key, ExternalLink, History, CheckCircle2, AlertCircle, Coins, Layers } from 'lucide-react';
import { ApiKeyEntry } from '../types';

interface NavbarProps {
  hasServerKey: boolean;
  apiKeys: ApiKeyEntry[];
  onOpenApiKeyModal: (tab?: 'kie' | 'gemini') => void;
  onToggleHistory: () => void;
  historyCount: number;
  creditInfo: { valid?: boolean; balance?: number | string } | null;
  checkingCredit: boolean;
  geminiApiKey?: string;
  hasServerGeminiKey?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  hasServerKey,
  apiKeys,
  onOpenApiKeyModal,
  onToggleHistory,
  historyCount,
  creditInfo,
  checkingCredit,
  geminiApiKey,
  hasServerGeminiKey = false,
}) => {
  const isKeyConfigured = hasServerKey || apiKeys.length > 0;
  const primaryKey = apiKeys.length > 0 ? apiKeys[0] : null;

  // Determine current display credit
  const displayCredit = primaryKey?.credit !== undefined ? primaryKey.credit : creditInfo?.balance;
  const isExhausted = displayCredit === 0 || displayCredit === '0';

  return (
    <header className="w-full border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand & Model identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-sm shadow-amber-950/40">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-zinc-100 tracking-tight text-base sm:text-lg">
                Kie AI
              </span>
              <span className="text-zinc-500 font-light text-sm">/</span>
              <span className="text-zinc-300 font-medium text-sm hidden sm:inline">
                Image Generator
              </span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-400/10 text-amber-300 border border-amber-400/20">
                GPT-Image 2.5 Flare
              </span>
            </div>
            <p className="text-xs text-zinc-400 hidden md:block">
              Photorealistic text-to-image & image-to-image with multi-key auto failover
            </p>
          </div>
        </div>

        {/* Right action controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Docs link */}
          <a
            id="docs-link"
            href="https://docs.kie.ai/market/gpt/gpt-image-2-5-flare-text-to-image"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900 border border-zinc-800/80 transition-colors"
            title="Read Kie.ai GPT-Image 2.5 Flare documentation"
          >
            <span>Docs</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          {/* History / Gallery Button */}
          <button
            id="history-toggle-btn"
            onClick={onToggleHistory}
            className="relative inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-300 hover:text-white bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 transition-colors"
          >
            <History className="w-3.5 h-3.5 text-zinc-400" />
            <span className="hidden sm:inline">Gallery</span>
            {historyCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {historyCount}
              </span>
            )}
          </button>

          {/* Multi-API Key & Remaining Credits Button */}
          <button
            id="api-key-config-btn"
            onClick={() => onOpenApiKeyModal('kie')}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
              !isKeyConfigured
                ? 'bg-amber-950/30 text-amber-300 border-amber-800/40 hover:bg-amber-900/30 animate-pulse'
                : isExhausted
                ? 'bg-rose-950/40 text-rose-300 border-rose-800/40 hover:bg-rose-900/30'
                : 'bg-emerald-950/30 text-emerald-300 border-emerald-800/40 hover:bg-emerald-900/30'
            }`}
            title="Kelola API Key Kie.ai & Kredit"
          >
            <Key className="w-3.5 h-3.5" />

            <div className="flex items-center gap-1.5">
              <span className="hidden sm:inline">
                {apiKeys.length > 1
                  ? `${apiKeys.length} Kie Keys`
                  : apiKeys.length === 1
                  ? apiKeys[0].name || 'Kie Key'
                  : hasServerKey
                  ? 'Server Key'
                  : 'Atur Kie Key'}
              </span>

              {isKeyConfigured ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              )}
            </div>

            {/* Display credits badge if available */}
            {displayCredit !== undefined && (
              <span
                className={`inline-flex items-center gap-1 pl-1.5 border-l text-[11px] font-semibold ${
                  isExhausted
                    ? 'border-rose-800/50 text-rose-300'
                    : 'border-emerald-800/50 text-emerald-200'
                }`}
              >
                <Coins className="w-3 h-3 text-amber-400" />
                {isExhausted ? '0 cr (Habis)' : `${displayCredit} cr`}
              </span>
            )}
          </button>

          {/* Gemini AI Key Switcher Button */}
          <button
            id="gemini-key-navbar-btn"
            type="button"
            onClick={() => onOpenApiKeyModal('gemini')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
              geminiApiKey
                ? 'bg-amber-500/10 text-amber-300 border-amber-500/40 hover:bg-amber-500/20 shadow-sm shadow-amber-950/20'
                : hasServerGeminiKey
                ? 'bg-zinc-900/90 text-zinc-300 border-zinc-700 hover:bg-zinc-800'
                : 'bg-zinc-900/60 text-zinc-400 border-dashed border-zinc-700 hover:text-zinc-200 hover:border-zinc-500'
            }`}
            title="Kelola & Ganti Gemini API Key (Gemini 3.5 Flash untuk Enhance Prompt)"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Gemini AI:</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold bg-zinc-950/80 text-amber-300 border border-zinc-800">
              {geminiApiKey ? 'Kustom' : hasServerGeminiKey ? 'Server' : 'Atur Key'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
