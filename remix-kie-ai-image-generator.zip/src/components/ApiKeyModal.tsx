import React, { useState, useEffect } from 'react';
import {
  Key,
  CheckCircle2,
  AlertCircle,
  X,
  ExternalLink,
  RefreshCw,
  Shield,
  Coins,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Sparkles,
  Layers,
  Check,
} from 'lucide-react';
import { ApiKeyEntry, GeminiApiKeyEntry } from '../types';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiKeys: ApiKeyEntry[];
  onUpdateApiKeys: React.Dispatch<React.SetStateAction<ApiKeyEntry[]>> | ((keys: ApiKeyEntry[] | ((prev: ApiKeyEntry[]) => ApiKeyEntry[])) => void);
  hasServerKey: boolean;
  onTestSingleKey: (key: string) => Promise<{ success: boolean; message: string; balance?: any }>;
  onCheckAllCredits: () => Promise<void>;
  checkingCredits: boolean;
  // Gemini AI props
  geminiApiKey: string;
  onUpdateGeminiApiKey: (key: string) => void;
  savedGeminiKeys: GeminiApiKeyEntry[];
  onUpdateSavedGeminiKeys: React.Dispatch<React.SetStateAction<GeminiApiKeyEntry[]>> | ((keys: GeminiApiKeyEntry[] | ((prev: GeminiApiKeyEntry[]) => GeminiApiKeyEntry[])) => void);
  hasServerGeminiKey?: boolean;
  initialTab?: 'kie' | 'gemini';
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({
  isOpen,
  onClose,
  apiKeys,
  onUpdateApiKeys,
  hasServerKey,
  onTestSingleKey,
  onCheckAllCredits,
  checkingCredits,
  geminiApiKey,
  onUpdateGeminiApiKey,
  savedGeminiKeys,
  onUpdateSavedGeminiKeys,
  hasServerGeminiKey = false,
  initialTab = 'kie',
}) => {
  const [activeTab, setActiveTab] = useState<'kie' | 'gemini'>(initialTab);

  // Kie.ai state
  const [newKeyInput, setNewKeyInput] = useState('');
  const [newKeyName, setNewKeyName] = useState('');
  const [revealedKeyIds, setRevealedKeyIds] = useState<Record<string, boolean>>({});
  const [testingKeyId, setTestingKeyId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ id: string; success: boolean; message: string } | null>(null);

  // Gemini state
  const [activeGeminiInput, setActiveGeminiInput] = useState(geminiApiKey);
  const [showActiveGeminiKey, setShowActiveGeminiKey] = useState(false);
  const [isTestingGemini, setIsTestingGemini] = useState(false);
  const [geminiFeedback, setGeminiFeedback] = useState<{ success: boolean; message: string } | null>(null);

  // Add new Gemini key to saved collection
  const [newGeminiKeyInput, setNewGeminiKeyInput] = useState('');
  const [newGeminiKeyName, setNewGeminiKeyName] = useState('');
  const [testingSavedGeminiId, setTestingSavedGeminiId] = useState<string | null>(null);

  // Keep state in sync with props
  useEffect(() => {
    if (isOpen) {
      if (initialTab) {
        setActiveTab(initialTab);
      }
      setActiveGeminiInput(geminiApiKey);
      setGeminiFeedback(null);
    }
  }, [isOpen, initialTab, geminiApiKey]);

  if (!isOpen) return null;

  const toggleReveal = (id: string) => {
    setRevealedKeyIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Helper to safely update Kie keys and immediately persist to both localStorage and sessionStorage
  const updateKieKeys = (updater: ApiKeyEntry[] | ((prev: ApiKeyEntry[]) => ApiKeyEntry[])) => {
    onUpdateApiKeys((prevKeys) => {
      const next = typeof updater === 'function' ? updater(prevKeys) : updater;
      try {
        localStorage.setItem('kie_ai_api_keys', JSON.stringify(next));
        sessionStorage.setItem('kie_ai_api_keys', JSON.stringify(next));
        if (next.length > 0) {
          localStorage.setItem('kie_ai_api_key', next[0].key);
          sessionStorage.setItem('kie_ai_api_key', next[0].key);
        } else {
          localStorage.removeItem('kie_ai_api_key');
          sessionStorage.removeItem('kie_ai_api_key');
        }
      } catch (e) {
        console.warn('Storage sync failed:', e);
      }
      return next;
    });
  };

  const handleAddKey = () => {
    const trimmedKey = newKeyInput.trim();
    if (!trimmedKey) return;

    // Check if key already exists
    if (apiKeys.some((k) => k.key === trimmedKey)) {
      setFeedback({ id: 'new', success: false, message: 'API Key ini sudah ada dalam daftar.' });
      return;
    }

    const defaultName = newKeyName.trim() || `API Key #${apiKeys.length + 1}`;
    const newEntry: ApiKeyEntry = {
      id: `key_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: defaultName,
      key: trimmedKey,
      status: 'unknown',
    };

    updateKieKeys((prev) => {
      if (prev.some((k) => k.key === trimmedKey)) return prev;
      return [...prev, newEntry];
    });

    setNewKeyInput('');
    setNewKeyName('');
    setFeedback({ id: newEntry.id, success: true, message: `Berhasil menyimpan ${defaultName}` });

    // Test credit safely using functional updater so the entry is never deleted
    handleTestKey(newEntry.id, trimmedKey);
  };

  const handleRemoveKey = (id: string) => {
    updateKieKeys((prev) => prev.filter((k) => k.id !== id));
    if (feedback?.id === id) setFeedback(null);
  };

  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    updateKieKeys((prev) => {
      if (index <= 0 || index >= prev.length) return prev;
      const next = [...prev];
      const temp = next[index - 1];
      next[index - 1] = next[index];
      next[index] = temp;
      return next;
    });
  };

  const handleMoveDown = (index: number) => {
    updateKieKeys((prev) => {
      if (index < 0 || index >= prev.length - 1) return prev;
      const next = [...prev];
      const temp = next[index + 1];
      next[index + 1] = next[index];
      next[index] = temp;
      return next;
    });
  };

  const handleTestKey = async (id: string, keyString: string) => {
    setTestingKeyId(id);
    try {
      const res = await onTestSingleKey(keyString);
      const isExhausted = res.balance === 0 || res.balance === '0';
      updateKieKeys((prev) => {
        return prev.map((k) => {
          if (k.id === id) {
            return {
              ...k,
              credit: res.balance !== undefined ? res.balance : k.credit,
              status: (!res.success ? 'invalid' : isExhausted ? 'exhausted' : 'active') as any,
              lastChecked: Date.now(),
              error: !res.success ? res.message : undefined,
            };
          }
          return k;
        });
      });
      setFeedback({
        id,
        success: res.success,
        message: res.success
          ? `Kredit tersisa: ${res.balance !== undefined ? res.balance : 'Aktif'}`
          : res.message,
      });
    } catch (e: any) {
      setFeedback({
        id,
        success: false,
        message: e.message || 'Gagal mengecek kredit.',
      });
    } finally {
      setTestingKeyId(null);
    }
  };

  // --- Gemini API Key Handlers ---
  const handleSaveActiveGeminiKey = () => {
    const trimmed = activeGeminiInput.trim();
    onUpdateGeminiApiKey(trimmed);
    try {
      if (trimmed) {
        localStorage.setItem('gemini_api_key', trimmed);
        sessionStorage.setItem('gemini_api_key', trimmed);
      } else {
        localStorage.removeItem('gemini_api_key');
        sessionStorage.removeItem('gemini_api_key');
      }
    } catch (e) {
      console.warn('Failed to save gemini_api_key to storage:', e);
    }

    // Also auto-add to saved list if not already present
    if (trimmed && !savedGeminiKeys.some((k) => k.key === trimmed)) {
      const autoEntry: GeminiApiKeyEntry = {
        id: `gemini_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: `Gemini Key #${savedGeminiKeys.length + 1}`,
        key: trimmed,
        status: 'active',
      };
      onUpdateSavedGeminiKeys((prev) => {
        if (prev.some((k) => k.key === trimmed)) return prev;
        const next = [...prev, autoEntry];
        try {
          localStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
          sessionStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
        } catch (err) {
          console.warn(err);
        }
        return next;
      });
    }

    setGeminiFeedback({
      success: true,
      message: trimmed
        ? 'Gemini API Key aktif berhasil disimpan di session & storage!'
        : 'Gemini API Key kustom dihapus (kembali ke default server jika ada).',
    });
  };

  const handleTestGeminiKey = async (keyToTest: string) => {
    const trimmed = keyToTest.trim();
    if (!trimmed) {
      setGeminiFeedback({
        success: false,
        message: 'Masukkan Gemini API Key terlebih dahulu untuk diuji.',
      });
      return;
    }

    setIsTestingGemini(true);
    setGeminiFeedback(null);

    try {
      const res = await fetch('/api/gemini/test-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: trimmed }),
      });

      const data = await res.json();
      if (res.ok && data.valid) {
        setGeminiFeedback({
          success: true,
          message: data.message || 'Gemini API Key valid dan aktif (Gemini 3.5 Flash)!',
        });
        // Also ensure key is updated and stored
        onUpdateGeminiApiKey(trimmed);
        try {
          localStorage.setItem('gemini_api_key', trimmed);
          sessionStorage.setItem('gemini_api_key', trimmed);
        } catch (e) {
          console.warn(e);
        }
      } else {
        setGeminiFeedback({
          success: false,
          message: data.error || 'Gemini API Key tidak valid atau kuota habis.',
        });
      }
    } catch (e: any) {
      setGeminiFeedback({
        success: false,
        message: e.message || 'Gagal menghubungi server untuk menguji Gemini key.',
      });
    } finally {
      setIsTestingGemini(false);
    }
  };

  const handleAddSavedGeminiKey = () => {
    const trimmed = newGeminiKeyInput.trim();
    if (!trimmed) return;

    if (savedGeminiKeys.some((k) => k.key === trimmed)) {
      setGeminiFeedback({
        success: false,
        message: 'Kunci Gemini ini sudah ada dalam daftar tersimpan.',
      });
      return;
    }

    const name = newGeminiKeyName.trim() || `Gemini Key #${savedGeminiKeys.length + 1}`;
    const newEntry: GeminiApiKeyEntry = {
      id: `gemini_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name,
      key: trimmed,
      status: 'unknown',
    };

    onUpdateSavedGeminiKeys((prev) => {
      if (prev.some((k) => k.key === trimmed)) return prev;
      const next = [...prev, newEntry];
      try {
        localStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
        sessionStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
      } catch (e) {
        console.warn(e);
      }
      return next;
    });

    // If currently no active key, also activate it
    if (!geminiApiKey) {
      onUpdateGeminiApiKey(trimmed);
      setActiveGeminiInput(trimmed);
      try {
        localStorage.setItem('gemini_api_key', trimmed);
        sessionStorage.setItem('gemini_api_key', trimmed);
      } catch (e) {
        console.warn(e);
      }
    }

    setNewGeminiKeyInput('');
    setNewGeminiKeyName('');
    setGeminiFeedback({
      success: true,
      message: `Berhasil menambahkan "${name}" ke daftar kunci tersimpan.`,
    });
  };

  const handleSwitchGeminiKey = (keyString: string, name: string) => {
    setActiveGeminiInput(keyString);
    onUpdateGeminiApiKey(keyString);
    try {
      localStorage.setItem('gemini_api_key', keyString);
      sessionStorage.setItem('gemini_api_key', keyString);
    } catch (e) {
      console.warn(e);
    }
    setGeminiFeedback({
      success: true,
      message: `Beralih ke "${name}". Kunci ini sekarang aktif!`,
    });
  };

  const handleRemoveSavedGeminiKey = (id: string) => {
    onUpdateSavedGeminiKeys((prev) => {
      const next = prev.filter((k) => k.id !== id);
      try {
        localStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
        sessionStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
      } catch (e) {
        console.warn(e);
      }
      return next;
    });
  };

  const handleTestSavedGeminiKey = async (id: string, keyString: string) => {
    setTestingSavedGeminiId(id);
    try {
      const res = await fetch('/api/gemini/test-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: keyString }),
      });
      const data = await res.json();
      onUpdateSavedGeminiKeys((prev) => {
        const next = prev.map((item) => {
          if (item.id === id) {
            return {
              ...item,
              status: (res.ok && data.valid ? 'active' : 'invalid') as any,
              lastChecked: Date.now(),
              error: res.ok && data.valid ? undefined : data.error,
            };
          }
          return item;
        });
        try {
          localStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
          sessionStorage.setItem('saved_gemini_api_keys', JSON.stringify(next));
        } catch (e) {
          console.warn(e);
        }
        return next;
      });
    } catch (err: any) {
      onUpdateSavedGeminiKeys((prev) => {
        return prev.map((item) => {
          if (item.id === id) {
            return {
              ...item,
              status: 'invalid' as any,
              lastChecked: Date.now(),
              error: err.message || 'Koneksi gagal',
            };
          }
          return item;
        });
      });
    } finally {
      setTestingSavedGeminiId(null);
    }
  };

  const maskKey = (key: string) => {
    if (!key) return '';
    if (key.length <= 10) return '••••••••••';
    return `${key.substring(0, 6)}••••••••${key.substring(key.length - 4)}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-150">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 shrink-0 bg-zinc-900/90 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                {activeTab === 'kie' ? <Layers className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
              </div>
              <div>
                <h3 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
                  <span>{activeTab === 'kie' ? 'Multi-API Key & Failover (Kie.ai)' : 'Google Gemini API Key (Enhance Prompt)'}</span>
                  {activeTab === 'kie' ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {apiKeys.length} Key
                    </span>
                  ) : (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        geminiApiKey
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : hasServerGeminiKey
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                      }`}
                    >
                      {geminiApiKey ? 'Kunci Kustom Aktif' : hasServerGeminiKey ? 'Server Default' : 'Belum Diatur'}
                    </span>
                  )}
                </h3>
                <p className="text-xs text-zinc-400">
                  {activeTab === 'kie'
                    ? 'Otomatis beralih ke API Key berikutnya jika kuota kredit pertama habis'
                    : 'Kelola & ganti-ganti API Key Gemini untuk fitur AI Enhance Prompt'}
                </p>
              </div>
            </div>
            <button
              id="close-api-key-modal"
              onClick={onClose}
              className="text-zinc-400 hover:text-zinc-200 p-1.5 rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 p-1 bg-zinc-950/80 rounded-xl border border-zinc-800">
            <button
              id="tab-kie-keys-btn"
              type="button"
              onClick={() => setActiveTab('kie')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'kie'
                  ? 'bg-amber-400 text-zinc-950 shadow-md shadow-amber-950/30'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Kie.ai Image Generator ({apiKeys.length})</span>
            </button>
            <button
              id="tab-gemini-key-btn"
              type="button"
              onClick={() => setActiveTab('gemini')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'gemini'
                  ? 'bg-amber-400 text-zinc-950 shadow-md shadow-amber-950/30'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Google Gemini AI (3.5 Flash)</span>
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-zinc-200">
          {activeTab === 'gemini' ? (
            /* TAB: Google Gemini AI */
            <div className="space-y-6 animate-in fade-in duration-150">
              {/* Info Banner */}
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <p className="font-semibold text-amber-200">Google Gemini 3.5 Flash Prompt Enhancer</p>
                  <p className="text-amber-300/80 leading-relaxed">
                    Fitur <strong>AI Enhance Prompt</strong> memperkaya ide deskripsi gambar Anda menjadi instruksi visual tingkat studio dengan pencahayaan sinematik, sudut lensa, dan tekstur mikro. Anda dapat memasukkan dan <strong>berganti-ganti API Key Gemini</strong> sesuka hati di bawah ini.
                  </p>
                </div>
              </div>

              {/* Server Key Info */}
              {hasServerGeminiKey && (
                <div className="p-3 rounded-xl bg-emerald-950/25 border border-emerald-800/30 flex items-start gap-2.5 text-xs text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Default Server Key Aktif: </span>
                    Server memiliki <code className="text-emerald-300 font-mono">GEMINI_API_KEY</code> bawaan. Kunci yang Anda aktifkan di bawah ini akan menggantikan kunci server secara instan.
                  </div>
                </div>
              )}

              {/* Active Gemini API Key Input Card */}
              <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800 space-y-3.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-400" />
                    Kunci Gemini Aktif Saat Ini
                  </label>
                  <a
                    href="https://aistudio.google.com/app/apikey"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <span>Dapatkan Key di Google AI Studio</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="space-y-2">
                  <div className="relative">
                    <input
                      type={showActiveGeminiKey ? 'text' : 'password'}
                      value={activeGeminiInput}
                      onChange={(e) => setActiveGeminiInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && activeGeminiInput.trim()) {
                          handleSaveActiveGeminiKey();
                        }
                      }}
                      placeholder="Tempelkan Gemini API Key Anda (AIzaSy...)"
                      className="w-full pl-3.5 pr-10 py-2.5 bg-zinc-900 border border-zinc-700 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 font-mono focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowActiveGeminiKey(!showActiveGeminiKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-200 cursor-pointer"
                    >
                      {showActiveGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-zinc-400">
                    Kunci ini otomatis tersimpan di sesi peramban dan langsung digunakan setiap kali Anda menekan tombol <strong>AI Enhance</strong>.
                  </p>
                </div>

                {/* Feedback */}
                {geminiFeedback && (
                  <div
                    className={`p-3 rounded-xl border flex items-center gap-2 text-xs ${
                      geminiFeedback.success
                        ? 'bg-emerald-950/30 border-emerald-800/30 text-emerald-300'
                        : 'bg-rose-950/30 border-rose-800/30 text-rose-300'
                    }`}
                  >
                    {geminiFeedback.success ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span>{geminiFeedback.message}</span>
                  </div>
                )}

                {/* Action Buttons for Active Key */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <button
                    type="button"
                    disabled={isTestingGemini || !activeGeminiInput.trim()}
                    onClick={() => handleTestGeminiKey(activeGeminiInput)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-200 disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isTestingGemini ? 'animate-spin text-amber-400' : ''}`} />
                    <span>{isTestingGemini ? 'Menguji ke Google...' : 'Uji Validitas Key'}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {geminiApiKey && (
                      <button
                        type="button"
                        onClick={() => {
                          setActiveGeminiInput('');
                          onUpdateGeminiApiKey('');
                          try {
                            localStorage.removeItem('gemini_api_key');
                            sessionStorage.removeItem('gemini_api_key');
                          } catch (e) {
                            console.warn(e);
                          }
                          setGeminiFeedback({
                            success: true,
                            message: hasServerGeminiKey
                              ? 'Kunci kustom dihapus. Kembali menggunakan server key.'
                              : 'Kunci kustom dihapus dari sesi.',
                          });
                        }}
                        className="px-3 py-1.5 rounded-lg text-xs text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 transition-colors cursor-pointer"
                      >
                        Reset / Hapus
                      </button>
                    )}
                    <button
                      id="save-active-gemini-key-btn"
                      type="button"
                      onClick={handleSaveActiveGeminiKey}
                      className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-amber-400 text-zinc-950 hover:bg-amber-300 transition-all cursor-pointer shadow-sm shadow-amber-950/40"
                    >
                      Simpan & Aktifkan
                    </button>
                  </div>
                </div>
              </div>

              {/* Saved Gemini Keys Collection (Quick Switcher) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-400" />
                    Koleksi Kunci Gemini Tersimpan (Ganti Kunci dengan 1-Klik)
                  </label>
                  <span className="text-[11px] text-zinc-400">{savedGeminiKeys.length} Kunci Tersimpan</span>
                </div>

                {savedGeminiKeys.length === 0 ? (
                  <div className="p-4 rounded-xl bg-zinc-950/40 border border-zinc-800/80 text-center space-y-1">
                    <p className="text-xs text-zinc-300">Belum ada daftar kunci tersimpan.</p>
                    <p className="text-[11px] text-zinc-500">
                      Tambahkan kunci cadangan atau akun Google lainnya di bawah agar Anda bisa berganti-ganti API Key dengan sekali klik.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {savedGeminiKeys.map((item) => {
                      const isActive = geminiApiKey === item.key;
                      const isTestingThis = testingSavedGeminiId === item.id;
                      return (
                        <div
                          key={item.id}
                          className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                            isActive
                              ? 'bg-amber-500/10 border-amber-500/40'
                              : 'bg-zinc-950/60 border-zinc-800/80 hover:border-zinc-700'
                          }`}
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-semibold text-zinc-200 truncate">{item.name}</span>
                              {isActive ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-zinc-950">
                                  <Check className="w-2.5 h-2.5" />
                                  Aktif Digunakan
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-zinc-800 text-zinc-300 border border-zinc-700">
                                  Tersimpan
                                </span>
                              )}
                              {item.status === 'active' && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/40">
                                  Valid
                                </span>
                              )}
                              {item.status === 'invalid' && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-950 text-rose-400 border border-rose-800/40">
                                  Gagal / Habis
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] font-mono text-zinc-400">{maskKey(item.key)}</p>
                            {item.error && <p className="text-[10px] text-rose-400 truncate">{item.error}</p>}
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
                            {!isActive && (
                              <button
                                type="button"
                                onClick={() => handleSwitchGeminiKey(item.key, item.name)}
                                className="px-3 py-1 rounded-lg text-xs font-semibold bg-amber-400 hover:bg-amber-300 text-zinc-950 transition-colors cursor-pointer"
                              >
                                Gunakan Key Ini
                              </button>
                            )}
                            <button
                              type="button"
                              title="Uji validitas kunci ini"
                              disabled={isTestingThis}
                              onClick={() => handleTestSavedGeminiKey(item.id, item.key)}
                              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors cursor-pointer"
                            >
                              <RefreshCw className={`w-3.5 h-3.5 ${isTestingThis ? 'animate-spin text-amber-400' : ''}`} />
                            </button>
                            <button
                              type="button"
                              title="Hapus dari daftar tersimpan"
                              onClick={() => handleRemoveSavedGeminiKey(item.id)}
                              className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-zinc-800 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Form: Simpan Kunci Gemini Baru ke Daftar */}
                <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-dashed border-zinc-800 space-y-2.5">
                  <span className="text-xs font-medium text-zinc-300 flex items-center gap-1.5">
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    Simpan Kunci Gemini Baru ke Koleksi
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <input
                      type="text"
                      placeholder="Nama / Label (cth: Akun Kantor)"
                      value={newGeminiKeyName}
                      onChange={(e) => setNewGeminiKeyName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && newGeminiKeyInput.trim()) {
                          handleAddSavedGeminiKey();
                        }
                      }}
                      className="px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-500/60"
                    />
                    <input
                      type="password"
                      placeholder="Gemini API Key (AIzaSy...)"
                      value={newGeminiKeyInput}
                      onChange={(e) => setNewGeminiKeyInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && newGeminiKeyInput.trim()) {
                          handleAddSavedGeminiKey();
                        }
                      }}
                      className="sm:col-span-2 px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 font-mono focus:outline-none focus:border-amber-500/60"
                    />
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="button"
                      disabled={!newGeminiKeyInput.trim()}
                      onClick={handleAddSavedGeminiKey}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-amber-400 border border-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer shadow-sm active:scale-98"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Simpan ke Koleksi</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Guide Card */}
              <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-800/80 space-y-1.5 text-xs text-zinc-400">
                <div className="flex items-center gap-1.5 font-medium text-zinc-300">
                  <Shield className="w-3.5 h-3.5 text-amber-400" />
                  <span>Panduan Kunci API Gemini:</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Kunjungi{' '}
                  <a
                    href="https://aistudio.google.com/app/apikey"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:underline inline-flex items-center gap-0.5 font-medium"
                  >
                    Google AI Studio (aistudio.google.com/app/apikey)
                    <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  untuk membuat API Key gratis. Semua kunci disimpan aman di penyimpanan lokal browser Anda dan diteruskan melalui endpoint server proksi yang aman.
                </p>
              </div>
            </div>
          ) : (
            /* TAB: Kie.ai Multi-Key */
            <>
              {/* Info Banner: Cara Kerja Failover */}
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <p className="font-semibold text-amber-200">Prinsip Pengalihan Otomatis (Failover)</p>
                  <p className="text-amber-300/80 leading-relaxed">
                    Sistem akan memprioritaskan <strong>Key Utama (Urutan #1)</strong>. Jika credit pada key pertama habis (0 atau insufficient credit), sistem <strong>secara otomatis berpindah ke Key berikutnya</strong> tanpa membatalkan proses generate gambar Anda.
                  </p>
                </div>
              </div>

              {/* Server Key Info if present */}
              {hasServerKey && (
                <div className="p-3 rounded-xl bg-emerald-950/25 border border-emerald-800/30 flex items-start gap-2.5 text-xs text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Default Server Key Tersedia: </span>
                    Aplikasi memiliki kunci server bawaan. Kunci yang Anda masukkan di bawah akan menjadi prioritas utama.
                  </div>
                </div>
              )}

              {/* List of Configured Keys */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-400" />
                    Daftar API Key & Sisa Kredit
                  </label>

                  {apiKeys.length > 0 && (
                    <button
                      id="check-all-credits-btn"
                      onClick={onCheckAllCredits}
                      disabled={checkingCredits}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${checkingCredits ? 'animate-spin text-amber-400' : ''}`} />
                      <span>{checkingCredits ? 'Memeriksa Saldo...' : 'Periksa Semua Kredit'}</span>
                    </button>
                  )}
                </div>

                {apiKeys.length === 0 ? (
                  <div className="p-6 rounded-xl border border-dashed border-zinc-800 text-center space-y-2">
                    <Coins className="w-8 h-8 text-zinc-600 mx-auto" />
                    <p className="text-xs text-zinc-400">
                      Belum ada API Key yang dikonfigurasi. Masukkan minimal 1 API Key Kie.ai Anda di bawah ini.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {apiKeys.map((item, index) => {
                      const isRevealed = Boolean(revealedKeyIds[item.id]);
                      const isTesting = testingKeyId === item.id;
                      const isPrimary = index === 0;

                      return (
                        <div
                          key={item.id}
                          className={`p-3.5 rounded-xl border transition-all ${
                            isPrimary
                              ? 'bg-amber-500/5 border-amber-500/30 shadow-sm shadow-amber-950/20'
                              : 'bg-zinc-950/60 border-zinc-800/80 hover:border-zinc-700'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="space-y-1 min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-xs font-semibold text-zinc-100 flex items-center gap-1.5 truncate">
                                  {isPrimary && (
                                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-zinc-950">
                                      Utama (#1)
                                    </span>
                                  )}
                                  {!isPrimary && (
                                    <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-zinc-800 text-zinc-400">
                                      #{index + 1}
                                    </span>
                                  )}
                                  {item.name}
                                </span>

                                {/* Status Badge */}
                                {item.status === 'active' && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-950/40 text-emerald-300 border border-emerald-800/40">
                                    <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                                    <span>Aktif (Kredit: {item.credit ?? 'OK'})</span>
                                  </span>
                                )}
                                {item.status === 'exhausted' && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-rose-950/40 text-rose-300 border border-rose-800/40">
                                    <AlertCircle className="w-2.5 h-2.5 text-rose-400" />
                                    <span>Kredit Habis</span>
                                  </span>
                                )}
                                {item.status === 'invalid' && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-rose-950/40 text-rose-300 border border-rose-800/40">
                                    <AlertCircle className="w-2.5 h-2.5 text-rose-400" />
                                    <span>Key Tidak Valid</span>
                                  </span>
                                )}
                                {(!item.status || item.status === 'unknown') && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-zinc-800/60 text-zinc-400 border border-zinc-700">
                                    <span>Belum Dicek</span>
                                  </span>
                                )}
                              </div>

                              {/* Masked Key Display */}
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs text-zinc-400">
                                  {isRevealed ? item.key : maskKey(item.key)}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => toggleReveal(item.id)}
                                  className="text-zinc-500 hover:text-zinc-300 p-0.5"
                                  title={isRevealed ? 'Sembunyikan' : 'Perlihatkan'}
                                >
                                  {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                </button>
                              </div>

                              {item.error && (
                                <p className="text-[11px] text-rose-400 truncate">{item.error}</p>
                              )}
                            </div>

                            {/* Key Action Buttons */}
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleTestKey(item.id, item.key)}
                                disabled={isTesting}
                                className="p-1.5 rounded-lg text-zinc-400 hover:text-amber-300 hover:bg-zinc-800/60 transition-colors"
                                title="Cek Saldo Key Ini"
                              >
                                <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin text-amber-400' : ''}`} />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleMoveUp(index)}
                                disabled={index === 0}
                                className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 disabled:opacity-20 transition-colors"
                                title="Naikkan Prioritas"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleMoveDown(index)}
                                disabled={index === apiKeys.length - 1}
                                className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 disabled:opacity-20 transition-colors"
                                title="Turunkan Prioritas"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRemoveKey(item.id)}
                                className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800/60 transition-colors"
                                title="Hapus Key"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Add New Key Form */}
              <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800 space-y-3">
                <label className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                  <Plus className="w-3.5 h-3.5 text-amber-400" />
                  Tambah API Key Kie.ai Baru
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <input
                    type="text"
                    value={newKeyName}
                    onChange={(e) => setNewKeyName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && newKeyInput.trim()) {
                        handleAddKey();
                      }
                    }}
                    placeholder="Nama / Label Key (opsional)"
                    className="px-3.5 py-2.5 bg-zinc-900 border border-zinc-700 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-500/60"
                  />
                  <input
                    type="password"
                    value={newKeyInput}
                    onChange={(e) => setNewKeyInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && newKeyInput.trim()) {
                        handleAddKey();
                      }
                    }}
                    placeholder="Tempelkan API Key Kie.ai di sini..."
                    className="sm:col-span-2 px-3.5 py-2.5 bg-zinc-900 border border-zinc-700 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 font-mono focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <p className="text-[11px] text-zinc-500">
                    Kunci otomatis tersimpan aman di penyimpanan peramban Anda.
                  </p>
                  <button
                    id="add-api-key-btn"
                    onClick={handleAddKey}
                    disabled={!newKeyInput.trim()}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-md shadow-amber-950/40 active:scale-98 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Simpan & Tambahkan Key</span>
                  </button>
                </div>

                {feedback?.id === 'new' && (
                  <p className="text-[11px] text-rose-400">{feedback.message}</p>
                )}
              </div>

              {/* Where to get Kie.ai keys */}
              <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-800/80 space-y-1.5 text-xs text-zinc-400">
                <div className="flex items-center gap-1.5 font-medium text-zinc-300">
                  <Shield className="w-3.5 h-3.5 text-amber-400" />
                  <span>Cara Mendapatkan & Mengisi Saldo API Key Kie.ai:</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Buka{' '}
                  <a
                    href="https://kie.ai"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:underline inline-flex items-center gap-0.5 font-medium"
                  >
                    kie.ai
                    <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  &gt; Dashboard Pengguna &gt; API Keys. Anda dapat membuat beberapa key untuk akun yang berbeda atau memantau saldo masing-masing akun langsung di sini.
                </p>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-zinc-950/90 border-t border-zinc-800 flex items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-zinc-400">
            {activeTab === 'kie' ? (
              apiKeys.length > 0 ? (
                <span>
                  Total <strong className="text-zinc-200">{apiKeys.length} API Key Kie.ai</strong> terkonfigurasi
                </span>
              ) : (
                <span>Tambahkan minimal 1 API Key Kie.ai untuk mulai generate</span>
              )
            ) : (
              <span>
                Status Gemini: <strong className="text-zinc-200">{geminiApiKey ? 'Kunci Kustom Aktif' : hasServerGeminiKey ? 'Server Default Aktif' : 'Belum Ada Kunci'}</strong>
              </span>
            )}
          </div>
          <button
            id="close-key-manager-btn"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 active:scale-98 transition-all shadow-md shadow-amber-950/50 cursor-pointer"
          >
            Selesai & Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
