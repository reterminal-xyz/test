import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Wand2,
  Lightbulb,
  ArrowRight,
  Plus,
  Undo2,
  Key,
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  X,
  ExternalLink,
  Camera,
  Palette,
  Eye,
  SlidersHorizontal,
  RefreshCw,
} from 'lucide-react';
import { STYLE_MODIFIERS, PROMPT_PRESETS, PromptPreset } from '../presets';
import { PromptEnhanceStyle } from '../types';

interface PromptInputProps {
  prompt: string;
  onChangePrompt: (val: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  onSelectPreset: (preset: PromptPreset) => void;
  onApplyStyleModifier: (modifier: string) => void;
  hasReferenceImage?: boolean;
  geminiApiKey?: string;
  hasServerGeminiKey?: boolean;
  onOpenApiKeyModal?: (tab?: 'kie' | 'gemini') => void;
}

const ENHANCE_STYLES: { id: PromptEnhanceStyle; label: string; desc: string; icon: any }[] = [
  {
    id: 'auto',
    label: 'Magic Auto',
    desc: 'Pengayaan cerdas & seimbang untuk pencahayaan, subjek, dan tekstur',
    icon: Sparkles,
  },
  {
    id: 'photorealistic',
    label: 'Photorealistic 8K',
    desc: 'Detail fotografi ultra-tajam, lensa Hasselblad, dan pencahayaan sinematik',
    icon: Camera,
  },
  {
    id: 'creative',
    label: 'Artistik & Konsep',
    desc: 'Seni konseptual fantasi, warna atmosferik, dan komposisi dramatis',
    icon: Palette,
  },
  {
    id: 'anime',
    label: 'Anime / Ilustrasi',
    desc: 'Gaya anime studio Makoto Shinkai, cel shading halus, dan garis tajam',
    icon: Eye,
  },
  {
    id: 'clarity',
    label: 'Ringkas & Tajam',
    desc: 'Hilangkan kata ambigu, fokus pada kata kunci visual yang presisi',
    icon: SlidersHorizontal,
  },
];

export const PromptInput: React.FC<PromptInputProps> = ({
  prompt,
  onChangePrompt,
  onGenerate,
  isGenerating,
  onSelectPreset,
  onApplyStyleModifier,
  hasReferenceImage = false,
  geminiApiKey,
  hasServerGeminiKey = false,
  onOpenApiKeyModal,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // AI Prompt Enhancement States
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState<PromptEnhanceStyle>('auto');
  const [showStyleMenu, setShowStyleMenu] = useState(false);
  const [previousPrompt, setPreviousPrompt] = useState<string | null>(null);
  const [showComparison, setShowComparison] = useState(false);
  const [enhanceNotification, setEnhanceNotification] = useState<{
    success: boolean;
    message: string;
    modelUsed?: string;
  } | null>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowStyleMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      if (!isGenerating && prompt.trim()) {
        onGenerate();
      }
    }
  };

  // Enhance Prompt execution using Gemini AI (Gemini 3.5 Flash)
  const handleEnhancePrompt = async (styleToUse: PromptEnhanceStyle = selectedStyle) => {
    const trimmedPrompt = prompt.trim();
    if (!trimmedPrompt) {
      setEnhanceNotification({
        success: false,
        message: 'Ketik deskripsi atau ide gambar terlebih dahulu agar Gemini AI dapat memperjelasnya.',
      });
      return;
    }

    setIsEnhancing(true);
    setEnhanceNotification(null);
    setShowStyleMenu(false);

    const activeGeminiKey =
      geminiApiKey?.trim() ||
      (() => {
        try {
          return localStorage.getItem('gemini_api_key') || sessionStorage.getItem('gemini_api_key') || '';
        } catch {
          return '';
        }
      })();

    try {
      const res = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(activeGeminiKey ? { 'x-gemini-api-key': activeGeminiKey } : {}),
        },
        body: JSON.stringify({
          prompt: trimmedPrompt,
          style: styleToUse,
          hasReferenceImage,
          geminiApiKey: activeGeminiKey || undefined,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success && data.enhancedPrompt) {
        setPreviousPrompt(trimmedPrompt);
        onChangePrompt(data.enhancedPrompt);
        setEnhanceNotification({
          success: true,
          message: `Prompt berhasil diperjelas dengan Gemini 3.5 Flash (${
            ENHANCE_STYLES.find((s) => s.id === styleToUse)?.label || styleToUse
          })!`,
          modelUsed: data.modelUsed,
        });
      } else {
        setEnhanceNotification({
          success: false,
          message: data.error || 'Gagal memperjelas prompt dengan Gemini AI.',
        });
        if (data.missingKey && onOpenApiKeyModal) {
          onOpenApiKeyModal('gemini');
        }
      }
    } catch (err: any) {
      setEnhanceNotification({
        success: false,
        message: err.message || 'Terjadi kesalahan saat menghubungi Gemini AI.',
      });
    } finally {
      setIsEnhancing(false);
    }
  };

  // Undo / Revert to previous prompt
  const handleUndo = () => {
    if (previousPrompt !== null) {
      const current = prompt;
      onChangePrompt(previousPrompt);
      setPreviousPrompt(current);
      setEnhanceNotification({
        success: true,
        message: 'Prompt dikembalikan ke versi sebelumnya.',
      });
      setShowComparison(false);
    }
  };

  const currentStyleObj = ENHANCE_STYLES.find((s) => s.id === selectedStyle) || ENHANCE_STYLES[0];
  const StyleIcon = currentStyleObj.icon;

  return (
    <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xl shadow-black/40 relative">
      {/* Header and Inspiration bar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-2 flex-wrap">
          <label
            htmlFor="prompt-textarea"
            className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5"
          >
            <Wand2 className="w-3.5 h-3.5 text-amber-400" />
            <span>{hasReferenceImage ? 'Describe Image Edits & Transformation' : 'Describe Your Image'}</span>
          </label>
        </div>

        {/* AI Enhance Prompt Controls */}
        <div className="flex items-center gap-1.5 relative" ref={dropdownRef}>
          {/* Main AI Enhance Button */}
          <button
            id="ai-enhance-prompt-btn"
            type="button"
            disabled={isEnhancing || !prompt.trim()}
            onClick={() => handleEnhancePrompt(selectedStyle)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/10 hover:from-amber-500/30 hover:to-orange-500/20 border border-amber-500/40 text-amber-300 hover:text-amber-200 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-sm shadow-amber-950/30 active:scale-98 cursor-pointer"
            title="Perjelas & perkaya deskripsi prompt dengan Gemini 3.5 Flash"
          >
            {isEnhancing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                <span className="font-medium">Memperjelas...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>AI Enhance</span>
                <span className="text-[10px] opacity-75 font-normal">({currentStyleObj.label})</span>
              </>
            )}
          </button>

          {/* Style Selector Dropdown Trigger */}
          <button
            id="ai-enhance-style-dropdown-btn"
            type="button"
            disabled={isEnhancing}
            onClick={() => setShowStyleMenu((prev) => !prev)}
            className="p-1.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-800 border border-zinc-700/80 text-zinc-300 hover:text-white transition-colors cursor-pointer"
            title="Pilih mode gaya AI Enhance"
          >
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showStyleMenu ? 'rotate-180' : ''}`} />
          </button>

          {/* Style Selector Menu Popup */}
          {showStyleMenu && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl p-2 z-40 space-y-1 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-2.5 py-1.5 border-b border-zinc-800 text-[11px] font-semibold text-zinc-400 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-zinc-200">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Mode Gaya AI Enhance (Gemini 3.5 Flash)
                </span>
              </div>
              <div className="space-y-0.5 pt-1">
                {ENHANCE_STYLES.map((style) => {
                  const Icon = style.icon;
                  const isSelected = selectedStyle === style.id;
                  return (
                    <button
                      key={style.id}
                      id={`style-option-${style.id}`}
                      type="button"
                      onClick={() => {
                        setSelectedStyle(style.id);
                        if (prompt.trim()) {
                          handleEnhancePrompt(style.id);
                        } else {
                          setShowStyleMenu(false);
                        }
                      }}
                      className={`w-full text-left p-2 rounded-xl transition-all flex items-start gap-2.5 cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/15 border border-amber-500/30 text-amber-200'
                          : 'hover:bg-zinc-800/70 text-zinc-300 border border-transparent'
                      }`}
                    >
                      <div
                        className={`p-1.5 rounded-lg shrink-0 ${
                          isSelected ? 'bg-amber-500/20 text-amber-400' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold">{style.label}</span>
                          {isSelected && <span className="text-[10px] text-amber-400 font-bold">Aktif</span>}
                        </div>
                        <p className="text-[10px] text-zinc-400 leading-tight mt-0.5">{style.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Gemini Key Quick Switcher in Dropdown */}
              <div className="p-2 border-t border-zinc-800 bg-zinc-950/80">
                <button
                  type="button"
                  onClick={() => {
                    setShowStyleMenu(false);
                    onOpenApiKeyModal?.('gemini');
                  }}
                  className="w-full text-left text-xs text-amber-300 hover:text-amber-200 flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 hover:bg-zinc-800 border border-zinc-800/80 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-1.5 font-medium">
                    <Key className="w-3.5 h-3.5 text-amber-400" />
                    <span>Ganti / Atur Gemini API Key</span>
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono">
                    {geminiApiKey ? 'Kustom' : hasServerGeminiKey ? 'Server' : 'Atur'}
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Textarea */}
      <div className="relative">
        <textarea
          ref={textareaRef}
          id="prompt-textarea"
          rows={3}
          value={prompt}
          onChange={(e) => onChangePrompt(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isEnhancing}
          placeholder={
            hasReferenceImage
              ? 'e.g. Ubah latar belakang menjadi kota futuristik neon saat hujan malam hari, pertahankan karakter dan pakaian dari gambar referensi, sinematik 8k...'
              : 'e.g. Photorealistic futuristic glass coffee machine on an obsidian kitchen counter, morning sunlight streaming through window, 8k commercial photography...'
          }
          className={`w-full px-4 py-3.5 bg-zinc-950/80 border rounded-xl text-sm sm:text-base text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-1 resize-y min-h-[105px] leading-relaxed transition-all ${
            isEnhancing
              ? 'border-amber-500/50 ring-1 ring-amber-500/30 opacity-70 animate-pulse cursor-wait'
              : 'border-zinc-800 focus:border-amber-500/60 focus:ring-amber-500/50'
          }`}
        />
        <div className="absolute right-3 bottom-3 text-[11px] text-zinc-400 font-mono pointer-events-none flex items-center gap-2 bg-zinc-950/80 px-2 py-0.5 rounded-md">
          {prompt.length} chars
        </div>
      </div>

      {/* Enhance Notification & Undo Bar */}
      {enhanceNotification && (
        <div
          className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs transition-all ${
            enhanceNotification.success
              ? 'bg-amber-950/20 border-amber-500/30 text-amber-200'
              : 'bg-rose-950/30 border-rose-800/40 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {enhanceNotification.success ? (
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span className="font-medium">{enhanceNotification.message}</span>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            {previousPrompt && (
              <>
                <button
                  id="undo-prompt-btn"
                  type="button"
                  onClick={handleUndo}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors cursor-pointer"
                  title="Kembalikan prompt ke versi sebelum diperjelas"
                >
                  <Undo2 className="w-3 h-3 text-amber-400" />
                  <span>Undo / Kembalikan</span>
                </button>

                <button
                  id="toggle-comparison-btn"
                  type="button"
                  onClick={() => setShowComparison((prev) => !prev)}
                  className="text-xs text-zinc-400 hover:text-zinc-200 underline transition-colors cursor-pointer"
                >
                  {showComparison ? 'Tutup Perbandingan' : 'Bandingkan'}
                </button>
              </>
            )}

            <button
              type="button"
              onClick={() => setEnhanceNotification(null)}
              className="p-1 rounded text-zinc-400 hover:text-zinc-200 transition-colors"
              title="Tutup pesan"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Side-by-side prompt comparison drawer if toggled */}
      {showComparison && previousPrompt && (
        <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs space-y-2">
          <div className="flex items-center justify-between text-[11px] font-semibold text-zinc-400">
            <span>Perbandingan Versi Prompt</span>
            <span className="text-amber-400">Sebelum vs Sesudah Diperjelas AI</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300">
              <span className="block text-[10px] uppercase font-bold text-zinc-400 mb-1">
                Prompt Awal (Original):
              </span>
              <p className="italic leading-relaxed">{previousPrompt}</p>
            </div>
            <div className="p-2.5 rounded-lg bg-amber-950/15 border border-amber-500/20 text-amber-200">
              <span className="block text-[10px] uppercase font-bold text-amber-400 mb-1">
                Prompt Hasil AI TokenRouter:
              </span>
              <p className="leading-relaxed">{prompt}</p>
            </div>
          </div>
        </div>
      )}

      {/* Style Modifiers Strip */}
      <div className="space-y-1.5">
        <div className="text-[11px] text-zinc-400 font-medium flex items-center justify-between">
          <span>Quick Style Modifiers:</span>
          <span className="text-[10px] text-zinc-400 hidden sm:inline">Klik untuk menambahkan ke akhir prompt</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {STYLE_MODIFIERS.map((style) => (
            <button
              key={style.label}
              id={`style-btn-${style.label.toLowerCase().replace(/\s+/g, '-')}`}
              type="button"
              onClick={() => onApplyStyleModifier(style.suffix)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs bg-zinc-950/70 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-amber-300 transition-colors cursor-pointer"
            >
              <Plus className="w-3 h-3 text-zinc-500" />
              <span>{style.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Preset Inspiration Pills */}
      <div className="pt-1 border-t border-zinc-800/80 space-y-2">
        <div className="flex items-center justify-between text-[11px] text-zinc-400 font-medium">
          <span className="flex items-center gap-1">
            <Lightbulb className="w-3 h-3 text-amber-400" />
            <span>Sample Prompts to Try:</span>
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {PROMPT_PRESETS.map((preset) => (
            <button
              key={preset.title}
              id={`preset-btn-${preset.title.toLowerCase().replace(/\s+/g, '-')}`}
              type="button"
              onClick={() => {
                onSelectPreset(preset);
                setPreviousPrompt(null);
                setEnhanceNotification(null);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 hover:border-amber-500/40 text-zinc-300 hover:text-zinc-100 transition-all text-left cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
              <span className="font-medium text-zinc-200">{preset.title}</span>
              <span className="text-[10px] text-zinc-400">({preset.category})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Action Footer with Generate Button */}
      <div className="pt-2 flex items-center justify-end gap-3">
        {prompt && (
          <button
            id="clear-prompt-btn"
            type="button"
            onClick={() => {
              onChangePrompt('');
              setPreviousPrompt(null);
              setEnhanceNotification(null);
            }}
            className="px-3 py-2 text-xs text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
          >
            Clear
          </button>
        )}
        <button
          id="generate-image-btn"
          type="button"
          disabled={isGenerating || !prompt.trim()}
          onClick={onGenerate}
          className="w-full sm:w-auto min-w-[220px] px-6 py-3 rounded-xl font-semibold text-sm text-zinc-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 active:scale-98 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 shadow-lg shadow-amber-950/40 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          {isGenerating ? (
            <>
              <div className="w-4 h-4 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
              <span>Generating with Flare...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-zinc-950" />
              <span>{hasReferenceImage ? 'Generate (Image-to-Image)' : 'Generate Image'}</span>
              <ArrowRight className="w-4 h-4 text-zinc-950/70 ml-1" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

