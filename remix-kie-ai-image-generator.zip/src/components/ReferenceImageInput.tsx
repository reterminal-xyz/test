import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  ImagePlus,
  X,
  Upload,
  Link as LinkIcon,
  Sparkles,
  Info,
  CheckCircle2,
  AlertCircle,
  Eye,
  Trash2,
  Youtube,
  Download,
  ArrowRight,
} from 'lucide-react';
import { ReferenceImageItem } from '../types';

interface ReferenceImageInputProps {
  referenceImages: ReferenceImageItem[];
  onAddReferenceImage: (item: ReferenceImageItem) => void;
  onRemoveReferenceImage: (id: string) => void;
  onClearAll: () => void;
  userApiKey?: string;
}

// Helper to extract YouTube video ID from any link format or direct ID
function extractYouTubeId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }
  const regex = /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/|live\/)|img\.youtube\.com\/vi\/|i\.ytimg\.com\/vi\/)([a-zA-Z0-9_-]{11})/i;
  const match = trimmed.match(regex);
  return match ? match[1] : null;
}

// Helper to normalize any client image to optimal JPG or PNG (max 2048px, optimized quality)
async function normalizeImageToStandardFormat(file: File): Promise<{ base64Data: string; fileName: string; size: number }> {
  return new Promise((resolve, reject) => {
    // If not standard image or file, check type
    if (!file.type.startsWith('image/') && !file.name.match(/\.(png|jpe?g|webp|avif|gif|bmp|heic|tiff)$/i)) {
      return reject(new Error('Format berkas tidak didukung. Harap pilih gambar (PNG, JPG, WebP, dsb).'));
    }

    const objectUrl = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);

      const naturalWidth = img.naturalWidth || img.width;
      const naturalHeight = img.naturalHeight || img.height;

      // Target max dimension 2048px (optimal balance between high quality and fast transfer)
      const MAX_SIZE = 2048;
      let width = naturalWidth;
      let height = naturalHeight;

      if (width > MAX_SIZE || height > MAX_SIZE) {
        if (width > height) {
          height = Math.round((height * MAX_SIZE) / width);
          width = MAX_SIZE;
        } else {
          width = Math.round((width * MAX_SIZE) / height);
          height = MAX_SIZE;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        // Fallback to FileReader
        const reader = new FileReader();
        reader.onload = () => resolve({
          base64Data: reader.result as string,
          fileName: file.name.replace(/\.[^/.]+$/, '') + '.jpg',
          size: file.size
        });
        reader.onerror = () => reject(new Error('Gagal membaca berkas gambar.'));
        reader.readAsDataURL(file);
        return;
      }

      // Check if image has transparency
      const isPng = file.type === 'image/png';
      let format = 'image/jpeg';
      let extension = 'jpg';

      if (isPng) {
        ctx.drawImage(img, 0, 0, width, height);
        try {
          const imgData = ctx.getImageData(0, 0, width, height).data;
          let hasAlpha = false;
          // Sample every 40th pixel to check for transparent pixels
          for (let i = 3; i < imgData.length; i += 40) {
            if (imgData[i] < 250) {
              hasAlpha = true;
              break;
            }
          }
          if (hasAlpha) {
            format = 'image/png';
            extension = 'png';
          }
        } catch {
          format = 'image/png';
          extension = 'png';
        }
      }

      if (format === 'image/jpeg') {
        // Fill canvas with white background before drawing
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
      }

      const quality = 0.92;
      const base64Data = canvas.toDataURL(format, quality);
      const cleanBaseName = file.name
        .replace(/\.[^/.]+$/, '')
        .replace(/[^a-zA-Z0-9_-]/g, '_')
        .slice(0, 30) || 'reference';
      const cleanFileName = `${cleanBaseName}.${extension}`;
      const approxSize = Math.round((base64Data.length * 3) / 4);

      resolve({
        base64Data,
        fileName: cleanFileName,
        size: approxSize,
      });
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      const reader = new FileReader();
      reader.onload = () => resolve({
        base64Data: reader.result as string,
        fileName: file.name.replace(/\.[^/.]+$/, '') + '.jpg',
        size: file.size,
      });
      reader.onerror = () => reject(new Error('Gagal memuat berkas gambar. Pastikan gambar tidak rusak.'));
      reader.readAsDataURL(file);
    };

    img.src = objectUrl;
  });
}

export const ReferenceImageInput: React.FC<ReferenceImageInputProps> = ({
  referenceImages,
  onAddReferenceImage,
  onRemoveReferenceImage,
  onClearAll,
  userApiKey,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'url' | 'youtube'>('upload');
  const [urlInput, setUrlInput] = useState('');
  const [youtubeInput, setYoutubeInput] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const maxImages = 3;
  const isMaxReached = referenceImages.length >= maxImages;

  // Auto detect YouTube video ID from youtubeInput
  const detectedYtId = useMemo(() => {
    return extractYouTubeId(youtubeInput);
  }, [youtubeInput]);

  // Global paste handler for images
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (isMaxReached) return;
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            handleProcessFile(file);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [referenceImages, isMaxReached, userApiKey]);

  // Upload file to server / Kie
  const uploadImagePayload = async (base64Data: string, fileName: string, size?: number) => {
    setIsUploading(true);
    setUploadError(null);
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (userApiKey?.trim()) {
        headers['Authorization'] = `Bearer ${userApiKey.trim()}`;
      }

      const res = await fetch('/api/upload-reference', {
        method: 'POST',
        headers,
        body: JSON.stringify({ base64Data, fileName }),
      });

      const data = await res.json();
      if (!res.ok || !data.url) {
        throw new Error(data.error || 'Gagal mengunggah gambar referensi');
      }

      const newItem: ReferenceImageItem = {
        id: `ref_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        url: data.url,
        previewUrl: base64Data.startsWith('data:') ? base64Data : data.url,
        name: fileName,
        size,
      };

      onAddReferenceImage(newItem);
    } catch (err: any) {
      setUploadError(err.message || 'Gagal memproses gambar referensi');
    } finally {
      setIsUploading(false);
    }
  };

  const handleProcessFile = async (file: File) => {
    if (isMaxReached) return;

    if (file.size > 15 * 1024 * 1024) {
      setUploadError('Ukuran file maksimal adalah 15MB.');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      // Automatically normalize and optimize image format into standard JPG or PNG
      const { base64Data, fileName, size } = await normalizeImageToStandardFormat(file);
      await uploadImagePayload(base64Data, fileName, size);
    } catch (err: any) {
      setUploadError(err.message || 'Gagal mengonversi gambar ke format yang didukung.');
      setIsUploading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleProcessFile(files[0]);
    }
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!isMaxReached) setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (isMaxReached) return;

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleProcessFile(e.dataTransfer.files[0]);
    }
  };

  // Process YouTube Thumbnail addition
  const handleFetchYouTube = async (customUrl?: string) => {
    const targetUrl = (customUrl || youtubeInput).trim();
    if (!targetUrl) return;

    const videoId = extractYouTubeId(targetUrl);
    if (!videoId) {
      setUploadError('Tautan YouTube tidak valid. Harap masukkan tautan video YouTube, Shorts, atau Video ID yang benar.');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (userApiKey?.trim()) {
        headers['Authorization'] = `Bearer ${userApiKey.trim()}`;
      }

      const res = await fetch('/api/upload-reference', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          youtubeUrl: targetUrl,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.url) {
        throw new Error(data.error || 'Gagal mengambil thumbnail YouTube.');
      }

      const newItem: ReferenceImageItem = {
        id: `ref_yt_${videoId}_${Date.now()}`,
        url: data.url,
        previewUrl: data.previewUrl || data.url || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        name: `YouTube: ${videoId}`,
      };

      onAddReferenceImage(newItem);
      setYoutubeInput('');
    } catch (err: any) {
      setUploadError(err.message || 'Gagal mengambil thumbnail YouTube. Pastikan video publik dan dapat diakses.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleAddFromUrl = async () => {
    const trimmed = urlInput.trim();
    if (!trimmed) return;

    // Smart auto-detect: if user pasted a YouTube link into the standard URL box, route to YouTube handler!
    const detectedYt = extractYouTubeId(trimmed);
    if (detectedYt) {
      await handleFetchYouTube(trimmed);
      setUrlInput('');
      return;
    }

    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      setUploadError('URL harus diawali dengan http:// atau https://');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (userApiKey?.trim()) {
        headers['Authorization'] = `Bearer ${userApiKey.trim()}`;
      }

      const res = await fetch('/api/upload-reference', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          imageUrl: trimmed,
          fileName: trimmed.split('/').pop()?.split('?')[0] || 'remote_reference.jpg',
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.url) {
        throw new Error(data.error || 'Gagal memproses gambar dari tautan luar.');
      }

      const newItem: ReferenceImageItem = {
        id: `ref_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        url: data.url,
        previewUrl: data.url,
        name: trimmed.split('/').pop()?.split('?')[0] || 'Remote Image',
      };

      onAddReferenceImage(newItem);
      setUrlInput('');
    } catch (err: any) {
      setUploadError(err.message || 'Gagal memproses gambar dari tautan. Pastikan URL dapat diakses publik.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="bg-zinc-900/80 border border-zinc-800/90 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xl shadow-black/30">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <ImagePlus className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-200">
                Gambar Referensi (Image-to-Image)
              </h3>
              {referenceImages.length > 0 && (
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30 flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" />
                  Mode I2I Aktif
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-zinc-400 font-mono">
            {referenceImages.length}/{maxImages}
          </span>
          {referenceImages.length > 0 && (
            <button
              id="clear-reference-images-btn"
              type="button"
              onClick={onClearAll}
              className="text-xs text-zinc-500 hover:text-rose-400 flex items-center gap-1 transition-colors px-1.5 py-0.5 rounded hover:bg-zinc-800"
              title="Hapus semua gambar referensi"
            >
              <Trash2 className="w-3 h-3" />
              <span className="hidden sm:inline">Hapus Semua</span>
            </button>
          )}
        </div>
      </div>

      {/* Selected Reference Thumbnails Strip */}
      {referenceImages.length > 0 && (
        <div className="space-y-2">
          <div className="grid grid-cols-3 sm:grid-cols-3 gap-2.5">
            {referenceImages.map((img, idx) => (
              <div
                key={img.id}
                className="relative group rounded-xl border border-amber-500/40 bg-zinc-950 overflow-hidden aspect-video sm:aspect-square flex items-center justify-center shadow-md"
              >
                <img
                  src={img.previewUrl || img.url}
                  alt={img.name || `Reference ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-400 text-zinc-950">
                      Ref #{idx + 1}
                    </span>
                    <button
                      id={`remove-ref-img-${idx}`}
                      type="button"
                      onClick={() => onRemoveReferenceImage(img.id)}
                      className="p-1 rounded-md bg-rose-500/80 text-white hover:bg-rose-600 transition-colors"
                      title="Hapus referensi ini"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[10px] text-zinc-200 truncate font-mono">
                    {img.name || 'Image source'}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300/90 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong>Panduan Referensi:</strong> GPT-Image 2.5 Flare akan menggunakan foto ini sebagai acuan subjek, pose, atau pencahayaan. Tulis instruksi perubahan yang Anda inginkan pada kolom deskripsi prompt di bawah.
            </p>
          </div>
        </div>
      )}

      {/* Upload Box / URL Input (shown when less than maxImages) */}
      {!isMaxReached && (
        <div className="space-y-3">
          {/* Method tabs */}
          <div className="flex items-center gap-1 p-1 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`flex-1 py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'upload'
                  ? 'bg-zinc-800 text-zinc-100 shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Upload className="w-3.5 h-3.5 text-amber-400" />
              <span className="truncate">Unggah / Tempel</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('url')}
              className={`flex-1 py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'url'
                  ? 'bg-zinc-800 text-zinc-100 shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <LinkIcon className="w-3.5 h-3.5 text-amber-400" />
              <span className="truncate">URL Web</span>
            </button>
            <button
              id="youtube-thumbnail-tab-btn"
              type="button"
              onClick={() => setActiveTab('youtube')}
              className={`flex-1 py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'youtube'
                  ? 'bg-red-950/60 text-red-200 border border-red-500/40 shadow-xs'
                  : 'text-zinc-400 hover:text-red-300'
              }`}
            >
              <Youtube className="w-3.5 h-3.5 text-red-500" />
              <span className="truncate">Thumbnail YouTube</span>
            </button>
          </div>

          {/* Tab 1: Drag & Drop Upload */}
          {activeTab === 'upload' && (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => !isUploading && fileInputRef.current?.click()}
              className={`p-5 rounded-xl border-2 border-dashed transition-all text-center cursor-pointer flex flex-col items-center justify-center gap-2 ${
                isDragging
                  ? 'border-amber-400 bg-amber-500/10'
                  : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/40 hover:bg-zinc-950/70'
              }`}
            >
              <input
                ref={fileInputRef}
                id="reference-image-file-input"
                type="file"
                accept="image/*,.png,.jpg,.jpeg,.webp,.avif,.heic,.bmp"
                onChange={handleFileChange}
                className="hidden"
              />

              {isUploading ? (
                <div className="py-2 flex flex-col items-center gap-2 text-amber-400">
                  <div className="w-6 h-6 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                  <span className="text-xs font-medium">Memproses & mengoptimalkan gambar referensi...</span>
                </div>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 group-hover:text-amber-400">
                    <Upload className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-zinc-200">
                      Tarik & lepas gambar ke sini, atau <span className="text-amber-400 underline">pilih dari perangkat</span>
                    </p>
                    <p className="text-[11px] text-zinc-500 mt-0.5">
                      Mendukung semua format gambar (PNG, JPG, WebP, dsb). Otomatis dioptimalkan untuk Kie.ai. Anda juga bisa menekan <kbd className="px-1 py-0.5 rounded bg-zinc-800 text-[10px] text-zinc-300 font-mono">Ctrl</kbd> + <kbd className="px-1 py-0.5 rounded bg-zinc-800 text-[10px] text-zinc-300 font-mono">V</kbd> untuk tempel gambar.
                    </p>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Tab 2: URL Input */}
          {activeTab === 'url' && (
            <div className="space-y-2">
              <div className="flex gap-2">
                <input
                  id="reference-image-url-input"
                  type="url"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddFromUrl();
                    }
                  }}
                  placeholder="https://example.com/sample-reference-photo.jpg atau link YouTube"
                  className="flex-1 px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/50 font-mono"
                />
                <button
                  id="add-reference-url-btn"
                  type="button"
                  onClick={handleAddFromUrl}
                  disabled={!urlInput.trim() || isUploading}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-amber-300 disabled:opacity-40 disabled:cursor-not-allowed border border-zinc-700 transition-colors"
                >
                  {isUploading ? 'Memproses...' : 'Tambahkan'}
                </button>
              </div>
              <p className="text-[11px] text-zinc-500">
                Masukkan tautan gambar publik atau link YouTube yang dapat diakses oleh server.
              </p>
            </div>
          )}

          {/* Tab 3: YouTube Thumbnail Input */}
          {activeTab === 'youtube' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-red-500">
                    <Youtube className="w-4 h-4" />
                  </div>
                  <input
                    id="youtube-url-input"
                    type="text"
                    value={youtubeInput}
                    onChange={(e) => setYoutubeInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleFetchYouTube();
                      }
                    }}
                    placeholder="Tempel tautan video YouTube, Shorts, atau Video ID"
                    className="w-full pl-9 pr-8 py-2.5 bg-zinc-950 border border-zinc-800 focus:border-red-500/60 focus:ring-1 focus:ring-red-500/40 rounded-xl text-xs text-zinc-100 placeholder-zinc-500 font-mono transition-colors"
                  />
                  {youtubeInput && (
                    <button
                      type="button"
                      onClick={() => setYoutubeInput('')}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-zinc-500 hover:text-zinc-300"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <button
                  id="fetch-youtube-btn"
                  type="button"
                  onClick={() => handleFetchYouTube()}
                  disabled={!youtubeInput.trim() || isUploading}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1.5 shadow-md shadow-red-900/20 shrink-0"
                >
                  {isUploading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Mengunduh...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>Ambil Thumbnail</span>
                    </>
                  )}
                </button>
              </div>

              {/* YouTube Thumbnail Live Preview Card if video ID is detected */}
              {detectedYtId ? (
                <div className="p-3 rounded-xl bg-zinc-950 border border-red-500/30 flex flex-col sm:flex-row items-center gap-3 shadow-inner">
                  <div className="relative w-full sm:w-36 aspect-video rounded-lg overflow-hidden border border-zinc-800 bg-black shrink-0">
                    <img
                      src={`https://img.youtube.com/vi/${detectedYtId}/hqdefault.jpg`}
                      alt="Pratinjau Thumbnail YouTube"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/80 text-[9px] font-mono text-white flex items-center gap-1">
                      <Youtube className="w-2.5 h-2.5 text-red-500" />
                      <span>HD / HQ</span>
                    </div>
                  </div>
                  <div className="flex-1 w-full flex flex-col justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-zinc-100">
                          Video ID Terdeteksi: <code className="text-amber-400 font-mono px-1 py-0.5 bg-zinc-900 rounded">{detectedYtId}</code>
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-1">
                        Thumbnail resolusi tinggi (1280x720 / 480p) siap diunduh otomatis dan dijadikan gambar referensi.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleFetchYouTube()}
                      disabled={isUploading}
                      className="self-start px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-zinc-950 flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Gunakan Sebagai Referensi</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-zinc-950/50 border border-zinc-800/80 text-[11px] text-zinc-400 space-y-1">
                  <p className="font-medium text-zinc-300 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-red-400" />
                    Format Tautan YouTube yang Didukung:
                  </p>
                  <ul className="list-disc list-inside text-zinc-500 pl-1 space-y-0.5 font-mono text-[10px]">
                    <li>https://www.youtube.com/watch?v=... (Tautan Video Biasa)</li>
                    <li>https://youtu.be/... (Tautan Singkat)</li>
                    <li>https://www.youtube.com/shorts/... (YouTube Shorts)</li>
                    <li>Atau langsung ketik/tempel 11 karakter Video ID</li>
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Upload Error Banner */}
      {uploadError && (
        <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-800/40 text-rose-300 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{uploadError}</span>
          </div>
          <button
            type="button"
            onClick={() => setUploadError(null)}
            className="text-rose-400 hover:text-rose-200 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
