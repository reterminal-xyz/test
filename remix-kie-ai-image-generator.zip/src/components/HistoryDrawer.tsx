import React from 'react';
import { X, Trash2, Maximize2, Sparkles, Clock, Copy, ArrowRight, ImagePlus } from 'lucide-react';
import { GeneratedImageItem } from '../types';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: GeneratedImageItem[];
  onSelectItem: (item: GeneratedImageItem) => void;
  onClearHistory: () => void;
  onUseAsReference?: (imageUrl: string, prompt?: string) => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onSelectItem,
  onClearHistory,
  onUseAsReference,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-zinc-950 border-l border-zinc-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-zinc-100">Generation Gallery</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 font-mono">
              {items.length}
            </span>
          </div>

          <div className="flex items-center gap-1">
            {items.length > 0 && (
              <button
                id="clear-gallery-btn"
                onClick={onClearHistory}
                className="p-1.5 text-zinc-500 hover:text-rose-400 rounded-lg hover:bg-zinc-900 transition-colors"
                title="Clear history"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              id="close-history-btn"
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-zinc-200 rounded-lg hover:bg-zinc-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List of items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {items.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-zinc-500">
              <Sparkles className="w-8 h-8 text-zinc-700 mb-2" />
              <p className="text-xs text-zinc-400 font-medium">No images generated yet</p>
              <p className="text-[11px] text-zinc-500 mt-1">
                Your generated images will automatically be saved here during your session.
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="group p-3 rounded-xl border border-zinc-800/80 bg-zinc-900/60 hover:bg-zinc-900 hover:border-zinc-700 transition-all space-y-2.5 cursor-pointer"
                onClick={() => {
                  onSelectItem(item);
                  onClose();
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="w-16 h-16 rounded-lg bg-zinc-950 border border-zinc-800 shrink-0 overflow-hidden relative flex items-center justify-center">
                    <img
                      src={item.url}
                      alt={item.prompt}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-zinc-200 font-medium line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </p>
                    <div className="flex items-center gap-1.5 mt-1.5 text-[10px] text-zinc-400 font-mono">
                      <span className="px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-300">
                        {item.aspect_ratio}
                      </span>
                      <span>•</span>
                      <span className="uppercase">{item.quality}</span>
                      <span>•</span>
                      <span>{new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-medium pt-1 border-t border-zinc-800/60 mt-1">
                  {onUseAsReference && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUseAsReference(item.url, item.prompt);
                        onClose();
                      }}
                      className="text-amber-400 hover:text-amber-300 flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-amber-500/10 transition-colors"
                      title="Gunakan sebagai gambar referensi"
                    >
                      <ImagePlus className="w-3 h-3" />
                      <span>Jadikan Referensi</span>
                    </button>
                  )}
                  <span className="flex items-center gap-1 text-zinc-400 group-hover:text-amber-400 transition-colors ml-auto">
                    Load Prompt <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
