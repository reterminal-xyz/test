import React, { useState } from 'react';
import { X, Download, Copy, Check, ZoomIn, ZoomOut, RotateCcw, ExternalLink, ImagePlus } from 'lucide-react';
import { GeneratedImageItem } from '../types';

interface ImageModalProps {
  item: GeneratedImageItem | null;
  onClose: () => void;
  onUsePrompt: (prompt: string, aspect: any, quality: any, bg: any) => void;
  onUseAsReference?: (imageUrl: string, prompt?: string) => void;
}

export const ImageModal: React.FC<ImageModalProps> = ({ item, onClose, onUsePrompt, onUseAsReference }) => {
  const [copied, setCopied] = useState(false);
  const [zoom, setZoom] = useState(1);

  if (!item) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(item.prompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const handleDownload = async () => {
    try {
      const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(item.url)}`;
      const res = await fetch(proxyUrl);
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      const cleanPrompt = item.prompt.slice(0, 30).replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
      a.download = `kie-flare_${cleanPrompt}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
    } catch (e) {
      window.open(item.url, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-5xl max-h-[95vh] bg-zinc-950 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Top Bar */}
        <div className="p-3.5 sm:p-4 border-b border-zinc-800 flex items-center justify-between gap-2 bg-zinc-900/80">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              GPT-Image 2.5 Flare
            </span>
            <span className="text-xs text-zinc-400 font-mono hidden sm:inline">
              {item.aspect_ratio} • {item.quality.toUpperCase()}
            </span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Zoom Controls */}
            <div className="flex items-center border border-zinc-800 rounded-lg overflow-hidden bg-zinc-900 mr-2">
              <button
                onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
                className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 text-[11px] font-mono text-zinc-300">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
                className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoom(1)}
                className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors border-l border-zinc-800"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={handleDownload}
              className="p-2 rounded-lg bg-amber-400 text-zinc-950 hover:bg-amber-300 text-xs font-medium flex items-center gap-1.5 transition-colors"
              title="Download full resolution"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Download</span>
            </button>

            <button
              id="close-lightbox-btn"
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-zinc-200 rounded-lg hover:bg-zinc-800 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Center Image Canvas */}
        <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-zinc-950 relative min-h-[300px]">
          {item.background === 'transparent' && (
            <div
              className="absolute inset-0 opacity-15"
              style={{
                backgroundImage:
                  'radial-gradient(#ffffff 1px, transparent 1px), radial-gradient(#ffffff 1px, #18181b 1px)',
                backgroundSize: '20px 20px',
                backgroundPosition: '0 0, 10px 10px',
              }}
            />
          )}
          <img
            src={item.url}
            alt={item.prompt}
            referrerPolicy="no-referrer"
            style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
            className="max-h-[68vh] object-contain rounded-lg transition-transform duration-150 relative z-10 shadow-2xl"
          />
        </div>

        {/* Modal Bottom Details */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-zinc-300 leading-relaxed font-sans line-clamp-2">
              <span className="text-zinc-500 font-semibold mr-1">Prompt:</span>
              {item.prompt}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium border border-zinc-700 flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Prompt'}</span>
            </button>
            {onUseAsReference && (
              <button
                onClick={() => {
                  onUseAsReference(item.url, item.prompt);
                  onClose();
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs font-medium border border-amber-500/30 flex items-center gap-1.5 transition-colors"
                title="Gunakan gambar ini sebagai referensi"
              >
                <ImagePlus className="w-3.5 h-3.5" />
                <span>Jadikan Referensi</span>
              </button>
            )}
            <button
              onClick={() => {
                onUsePrompt(item.prompt, item.aspect_ratio, item.quality, item.background);
                onClose();
              }}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-zinc-100 text-xs font-medium border border-zinc-700 transition-colors"
            >
              Remix Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
