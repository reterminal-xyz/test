import React from 'react';
import {
  Square,
  RectangleHorizontal,
  RectangleVertical,
  LayoutGrid,
  Columns,
  Camera,
  Film,
  Layers,
  Sparkles,
  SlidersHorizontal,
} from 'lucide-react';
import { AspectRatioId, QualityTier, BackgroundMode, ModelOption } from '../types';
import { ASPECT_RATIOS, QUALITIES, DEFAULT_MODELS } from '../presets';

interface ModelSettingsProps {
  model: string;
  onChangeModel: (model: string) => void;
  aspectRatio: AspectRatioId;
  onChangeAspectRatio: (ratio: AspectRatioId) => void;
  quality: QualityTier;
  onChangeQuality: (quality: QualityTier) => void;
  background: BackgroundMode;
  onChangeBackground: (bg: BackgroundMode) => void;
  supportedModels?: ModelOption[];
}

export const ModelSettings: React.FC<ModelSettingsProps> = ({
  model,
  onChangeModel,
  aspectRatio,
  onChangeAspectRatio,
  quality,
  onChangeQuality,
  background,
  onChangeBackground,
  supportedModels = DEFAULT_MODELS,
}) => {
  const getAspectIcon = (id: AspectRatioId) => {
    switch (id) {
      case '1:1':
        return <Square className="w-3.5 h-3.5" />;
      case '16:9':
        return <RectangleHorizontal className="w-4 h-3.5" />;
      case '9:16':
        return <RectangleVertical className="w-3.5 h-4" />;
      case '4:3':
        return <LayoutGrid className="w-3.5 h-3.5" />;
      case '3:4':
        return <Columns className="w-3.5 h-3.5" />;
      case '3:2':
        return <Camera className="w-3.5 h-3.5" />;
      case '2:3':
        return <Film className="w-3.5 h-3.5" />;
      default:
        return <Square className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="bg-zinc-900/70 border border-zinc-800/80 rounded-2xl p-4 sm:p-5 space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-300">
          <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
          <span>Generation Parameters</span>
        </div>
        <span className="text-[11px] text-zinc-500 font-medium">
          OpenAI GPT Image 2.5 API
        </span>
      </div>

      {/* Model Selection */}
      <div className="space-y-2">
        <label className="text-xs font-medium text-zinc-400 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Model Engine</span>
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {supportedModels.map((item) => {
            const isSelected = model === item.id;
            return (
              <button
                key={item.id}
                id={`model-select-${item.id}`}
                type="button"
                onClick={() => onChangeModel(item.id)}
                className={`text-left p-2.5 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500/40 text-zinc-100 shadow-sm'
                    : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-300'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className={`text-xs font-semibold ${isSelected ? 'text-amber-300' : 'text-zinc-200'}`}>
                    {item.name}
                  </span>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${
                        isSelected
                          ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </div>
                <p className="text-[10px] leading-tight text-zinc-400 line-clamp-2">
                  {item.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Aspect Ratio Selector */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-medium text-zinc-400">
            Aspect Ratio
          </label>
          <span className="text-[11px] text-zinc-400 font-mono">
            {ASPECT_RATIOS.find((r) => r.id === aspectRatio)?.width} ×{' '}
            {ASPECT_RATIOS.find((r) => r.id === aspectRatio)?.height}
          </span>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-7 gap-1.5">
          {ASPECT_RATIOS.map((item) => {
            const isSelected = aspectRatio === item.id;
            return (
              <button
                key={item.id}
                id={`aspect-ratio-${item.id.replace(':', '-')}`}
                type="button"
                onClick={() => onChangeAspectRatio(item.id)}
                className={`flex flex-col items-center justify-center p-2 rounded-xl border text-center transition-all ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                    : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200'
                }`}
              >
                <span className="mb-1">{getAspectIcon(item.id)}</span>
                <span className="text-[11px] font-semibold">{item.id}</span>
                <span className="text-[9px] text-zinc-400 truncate max-w-full">
                  {item.id === '1:1' ? 'Square' : item.id === '16:9' ? 'Wide' : item.id === '9:16' ? 'Reel' : item.id}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Quality Tier and Background Mode in 2 columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
        {/* Quality Tiers */}
        <div className="space-y-2">
          <label className="text-xs font-medium text-zinc-400">
            Quality Level
          </label>
          <div className="grid grid-cols-5 gap-1">
            {QUALITIES.map((q) => {
              const isSelected = quality === q.id;
              return (
                <button
                  key={q.id}
                  id={`quality-tier-${q.id}`}
                  type="button"
                  onClick={() => onChangeQuality(q.id)}
                  title={q.desc}
                  className={`py-1.5 px-2 rounded-lg border text-center transition-all ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-semibold'
                      : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 text-xs'
                  }`}
                >
                  <span className="text-xs block">{q.label}</span>
                </button>
              );
            })}
          </div>
          <p className="text-[11px] text-zinc-400">
            {QUALITIES.find((q) => q.id === quality)?.desc}
          </p>
        </div>

        {/* Background Mode */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-zinc-400 flex items-center gap-1">
              <Layers className="w-3 h-3 text-amber-400" />
              <span>Background Canvas</span>
            </label>
            <span className="text-[10px] text-amber-300 font-medium">
              Flare feature
            </span>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'auto' as BackgroundMode, label: 'Auto', desc: 'AI decides' },
              { id: 'opaque' as BackgroundMode, label: 'Opaque', desc: 'Full scenery' },
              { id: 'transparent' as BackgroundMode, label: 'Transparent', desc: 'Cutout asset' },
            ].map((b) => {
              const isSelected = background === b.id;
              return (
                <button
                  key={b.id}
                  id={`background-mode-${b.id}`}
                  type="button"
                  onClick={() => onChangeBackground(b.id)}
                  className={`p-2 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                      : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200'
                  }`}
                >
                  <span className="text-xs font-semibold block">{b.label}</span>
                  <span className="text-[10px] text-zinc-400 block">{b.desc}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
